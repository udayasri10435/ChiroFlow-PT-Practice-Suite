export type UserRole = 'chiropractor' | 'physical_therapist' | 'biller' | 'receptionist';

export interface Provider {
  id: string;
  name: string;
  credentials: string; // e.g., 'DC, CCSP' or 'PT, DPT, OCS'
  role: 'chiropractor' | 'physical_therapist';
  specialty: string;
  npi: string;
  color: string;
  avatarInitials: string;
  defaultRoom: string;
}

export interface InsuranceInfo {
  payerName: string;
  payerId: string;
  policyId: string;
  groupNumber: string;
  copayAmount: number;
  deductibleRemaining: number;
  preAuthNumber?: string;
  visitsAuthorized?: number;
  visitsUsed?: number;
}

export interface Diagnosis {
  code: string; // ICD-10
  description: string;
  isPrimary: boolean;
  dateAdded: string;
}

export interface Patient {
  id: string;
  mrn: string; // Medical Record Number e.g. MRN-8492
  firstName: string;
  lastName: string;
  dob: string;
  gender: 'M' | 'F' | 'Other';
  phone: string;
  email: string;
  address: string;
  insurance: InsuranceInfo;
  primaryProviderId: string;
  diagnoses: Diagnosis[];
  episodeStart: string;
  carePlanPhase: 'Acute Relief' | 'Corrective Care' | 'Strengthening Rehab' | 'Maintenance / Wellness';
  totalVisits: number;
  lastVisitDate: string;
  currentPainVas: number; // 0-10
}

export type AppointmentType = 
  | 'chiro_adjust'
  | 'pt_rehab'
  | 'initial_eval'
  | 'decompression'
  | 'dry_needling'
  | 're_exam'
  | 'telehealth';

export type AppointmentStatus =
  | 'scheduled'
  | 'arrived'
  | 'in_session'
  | 'completed'
  | 'cancelled'
  | 'no_show';

export interface Appointment {
  id: string;
  patientId: string;
  providerId: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  durationMinutes: number; // 15, 30, 45, 60
  type: AppointmentType;
  room: string;
  status: AppointmentStatus;
  chiefComplaint: string;
  copayCollected: boolean;
  copayAmount: number;
  notes?: string;
  soapNoteId?: string;
  claimId?: string;
}

export interface SpineSubluxation {
  segment: string; // e.g., 'C1', 'C2', 'C5', 'T4', 'L4', 'L5', 'Sacrum', 'Right SI'
  listing: string; // 'PR', 'PL', 'PRS', 'PLS', 'Subluxated', 'Fixated'
  technique: 'Diversified' | 'Activator' | 'Drop Table' | 'Gonstead' | 'Flexion-Distraction';
  tenderness: 0 | 1 | 2 | 3; // 0 none, 3 severe
}

export interface RomMeasurement {
  region: 'Cervical' | 'Lumbar' | 'Shoulder' | 'Knee';
  movement: string; // e.g. 'Flexion', 'Extension', 'Right Rotation'
  measuredDegrees: number;
  normalDegrees: number;
  painOnMotion: boolean;
}

export interface SoapNote {
  id: string;
  appointmentId: string;
  patientId: string;
  providerId: string;
  date: string;
  time: string;
  subjective: {
    chiefComplaint: string;
    vasScore: number; // 0-10
    symptomsDescription: string;
    functionalLimitations: string;
    aggravatingFactors: string;
    relievingFactors: string;
  };
  objective: {
    subluxations: SpineSubluxation[];
    roms: RomMeasurement[];
    postureFindings: string;
    palpationNotes: string;
    muscleSpasmGrade: '0 Normal' | '1+ Mild' | '2+ Moderate' | '3+ Severe';
    specialTests: string; // e.g. 'Straight Leg Raise negative bilaterally, Kemp test positive on right'
  };
  assessment: {
    clinicalProgress: 'Significant Improvement' | 'Moderate Progress' | 'Stable / Plateau' | 'Acute Flare-up';
    prognosis: string;
    treatmentTolerance: string;
    icd10Codes: string[];
  };
  plan: {
    cptCodes: string[];
    spinalAdjustments: string;
    modalitiesDelivered: string[];
    homeExercisesPrescribed: string;
    frequencyAndDuration: string;
    nextVisitDate: string;
  };
  signed: boolean;
  signedBy?: string;
  signedAt?: string;
}

export interface ClaimLineItem {
  id: string;
  cptCode: string;
  description: string;
  modifier?: string; // e.g., '59', 'GP', 'GY'
  units: number;
  chargePerUnit: number;
  totalCharge: number;
  allowedAmount: number;
  copayApplied: number;
  diagPointer: string; // 'A', 'AB', 'B'
}

export type ClaimStatus = 'draft' | 'scrubbed' | 'submitted' | 'in_review' | 'paid' | 'denied';

export interface Claim {
  id: string;
  claimNumber: string;
  patientId: string;
  providerId: string;
  appointmentId?: string;
  serviceDate: string;
  filingDate: string;
  insurancePayer: string;
  payerId: string;
  policyNumber: string;
  groupNumber: string;
  icd10Codes: Diagnosis[];
  lines: ClaimLineItem[];
  totalCharges: number;
  patientResponsibility: number;
  insurancePaidAmount: number;
  status: ClaimStatus;
  scrubErrors?: string[];
  paymentReference?: string;
  notes?: string;
}

export interface OutcomeQuestionAnswer {
  questionId: string;
  sectionTitle: string;
  questionText: string;
  selectedScore: number;
  selectedText: string;
}

export interface OutcomeMeasure {
  id: string;
  patientId: string;
  providerId: string;
  date: string;
  type: 'ODI' | 'NDI' | 'LEFS' | 'QuickDASH' | 'VAS';
  title: string;
  rawScore: number;
  maxScore: number;
  percentageScore: number;
  severityLevel: string;
  interpretation: string;
  answers: OutcomeQuestionAnswer[];
  clinicalSignificanceNotes: string;
  visitMilestone: 'Intake / Baseline' | '2-Week Progress' | '4-Week Progress' | '8-Week Discharge / Re-eval';
}

export interface ExerciseItem {
  id: string;
  name: string;
  region: 'Cervical' | 'Thoracic' | 'Lumbar / Pelvis' | 'Shoulder' | 'Hip / Knee';
  category: 'Mobility' | 'Stabilization' | 'Strengthening' | 'Nerve Glide';
  targetMuscles: string;
  sets: number;
  reps: number;
  holdSeconds: number;
  instructions: string[];
  clinicalPurpose: string;
  commonMistakes: string;
  svgIcon: string;
}

export interface TelehealthSession {
  id: string;
  patientId: string;
  providerId: string;
  appointmentId: string;
  scheduledTime: string;
  status: 'ready' | 'in_call' | 'completed';
  callDurationSeconds: number;
  currentExercise?: ExerciseItem;
  exerciseCompletedCount: number;
  isMicMuted: boolean;
  isCameraOff: boolean;
  isScreenSharing: boolean;
  postureGuideOverlay: boolean;
  clinicianNotes: string;
}
