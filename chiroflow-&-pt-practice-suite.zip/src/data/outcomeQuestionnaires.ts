export interface QuestionnaireTemplate {
  id: 'ODI' | 'NDI' | 'LEFS' | 'QuickDASH';
  title: string;
  subtitle: string;
  clinicalDomain: 'Lumbar Spine' | 'Cervical Spine' | 'Lower Extremity' | 'Upper Extremity / Shoulder';
  description: string;
  mcidThreshold: number; // Minimal Clinically Important Difference
  sections: Array<{
    id: string;
    title: string;
    options: Array<{
      score: number;
      text: string;
    }>;
  }>;
  calculateScore: (answers: Record<string, number>) => {
    rawScore: number;
    maxScore: number;
    percentage: number;
    severityLevel: string;
    clinicalInterpretation: string;
  };
}

export const QUESTIONNAIRE_TEMPLATES: Record<string, QuestionnaireTemplate> = {
  ODI: {
    id: 'ODI',
    title: 'Oswestry Low Back Disability Index (ODI)',
    subtitle: 'Standardized assessment for lumbar spine and low back functional impairment',
    clinicalDomain: 'Lumbar Spine',
    description: 'Gold-standard questionnaire assessing how lower back pain affects patient ability to manage everyday life activities.',
    mcidThreshold: 10,
    sections: [
      {
        id: 'sec_pain',
        title: 'Section 1 — Pain Intensity',
        options: [
          { score: 0, text: 'I have no pain at the moment.' },
          { score: 1, text: 'The pain is very mild at the moment.' },
          { score: 2, text: 'The pain is moderate at the moment.' },
          { score: 3, text: 'The pain is fairly severe at the moment.' },
          { score: 4, text: 'The pain is very severe at the moment.' },
          { score: 5, text: 'The pain is the worst imaginable at the moment.' },
        ],
      },
      {
        id: 'sec_personal',
        title: 'Section 2 — Personal Care (Washing, Dressing, etc.)',
        options: [
          { score: 0, text: 'I can look after myself normally without causing extra pain.' },
          { score: 1, text: 'I can look after myself normally but it causes extra pain.' },
          { score: 2, text: 'It is painful to look after myself and I am slow and careful.' },
          { score: 3, text: 'I need some help but manage most of my personal care.' },
          { score: 4, text: 'I need help every day in most aspects of self care.' },
          { score: 5, text: 'I cannot get dressed, I wash with difficulty and stay in bed.' },
        ],
      },
      {
        id: 'sec_lifting',
        title: 'Section 3 — Lifting',
        options: [
          { score: 0, text: 'I can lift heavy weights without extra pain.' },
          { score: 1, text: 'I can lift heavy weights but it gives extra pain.' },
          { score: 2, text: 'Pain prevents me from lifting heavy weights off the floor, but I can manage if they are conveniently positioned.' },
          { score: 3, text: 'Pain prevents me from lifting heavy weights, but I can manage light to medium weights if conveniently positioned.' },
          { score: 4, text: 'I can only lift very light weights.' },
          { score: 5, text: 'I cannot lift or carry anything at all.' },
        ],
      },
      {
        id: 'sec_walking',
        title: 'Section 4 — Walking',
        options: [
          { score: 0, text: 'Pain does not prevent me walking any distance.' },
          { score: 1, text: 'Pain prevents me from walking more than 1 mile.' },
          { score: 2, text: 'Pain prevents me from walking more than 1/2 mile.' },
          { score: 3, text: 'Pain prevents me from walking more than 100 yards.' },
          { score: 4, text: 'I can only walk using a cane or crutches.' },
          { score: 5, text: 'I am in bed most of the time and have to crawl to the toilet.' },
        ],
      },
      {
        id: 'sec_sitting',
        title: 'Section 5 — Sitting',
        options: [
          { score: 0, text: 'I can sit in any chair as long as I like.' },
          { score: 1, text: 'I can only sit in my favorite chair as long as I like.' },
          { score: 2, text: 'Pain prevents me from sitting for more than 1 hour.' },
          { score: 3, text: 'Pain prevents me from sitting for more than 30 minutes.' },
          { score: 4, text: 'Pain prevents me from sitting for more than 10 minutes.' },
          { score: 5, text: 'Pain prevents me from sitting at all.' },
        ],
      },
      {
        id: 'sec_standing',
        title: 'Section 6 — Standing',
        options: [
          { score: 0, text: 'I can stand as long as I want without extra pain.' },
          { score: 1, text: 'I can stand as long as I want but it gives me extra pain.' },
          { score: 2, text: 'Pain prevents me from standing for more than 1 hour.' },
          { score: 3, text: 'Pain prevents me from standing for more than 30 minutes.' },
          { score: 4, text: 'Pain prevents me from standing for more than 10 minutes.' },
          { score: 5, text: 'Pain prevents me from standing at all.' },
        ],
      },
      {
        id: 'sec_sleeping',
        title: 'Section 7 — Sleeping',
        options: [
          { score: 0, text: 'My sleep is never disturbed by pain.' },
          { score: 1, text: 'My sleep is occasionally disturbed by pain.' },
          { score: 2, text: 'Because of pain I have less than 6 hours sleep.' },
          { score: 3, text: 'Because of pain I have less than 4 hours sleep.' },
          { score: 4, text: 'Because of pain I have less than 2 hours sleep.' },
          { score: 5, text: 'Pain prevents me from sleeping at all.' },
        ],
      },
      {
        id: 'sec_social',
        title: 'Section 8 — Social Life',
        options: [
          { score: 0, text: 'My social life is normal and gives me no extra pain.' },
          { score: 1, text: 'My social life is normal but increases the degree of pain.' },
          { score: 2, text: 'Pain has no significant effect on my social life apart from limiting energetic interests like dancing.' },
          { score: 3, text: 'Pain has restricted my social life and I do not go out as often.' },
          { score: 4, text: 'Pain has restricted my social life to my home.' },
          { score: 5, text: 'I have no social life because of pain.' },
        ],
      },
      {
        id: 'sec_traveling',
        title: 'Section 9 — Traveling',
        options: [
          { score: 0, text: 'I can travel anywhere without pain.' },
          { score: 1, text: 'I can travel anywhere but it gives me extra pain.' },
          { score: 2, text: 'Pain is bad but I manage journeys over 2 hours.' },
          { score: 3, text: 'Pain restricts me to journeys of less than 1 hour.' },
          { score: 4, text: 'Pain restricts me to short necessary journeys under 30 minutes.' },
          { score: 5, text: 'Pain prevents me from traveling except to receive treatment.' },
        ],
      },
      {
        id: 'sec_employment',
        title: 'Section 10 — Employment / Homemaking',
        options: [
          { score: 0, text: 'My normal work activities do not cause pain.' },
          { score: 1, text: 'My normal work activities cause extra pain, but I can still perform all duties.' },
          { score: 2, text: 'I can perform most of my work duties, but not the physically demanding parts.' },
          { score: 3, text: 'Pain prevents me from doing anything but light work duties.' },
          { score: 4, text: 'Pain prevents me from doing even light duties.' },
          { score: 5, text: 'Pain prevents me from doing any work at all.' },
        ],
      },
    ],
    calculateScore: (answers) => {
      const keys = Object.keys(answers);
      const answeredCount = keys.length;
      if (answeredCount === 0) {
        return { rawScore: 0, maxScore: 50, percentage: 0, severityLevel: 'Pending', clinicalInterpretation: 'No sections answered yet.' };
      }
      const rawScore = keys.reduce((sum, k) => sum + (answers[k] ?? 0), 0);
      const maxScore = answeredCount * 5;
      const percentage = Math.round((rawScore / maxScore) * 100);

      let severityLevel = '0-20%: Minimal Disability';
      let clinicalInterpretation = 'Patient can cope with most activities of daily living. Conservative therapy, postural education, and core conditioning are indicated.';

      if (percentage >= 21 && percentage <= 40) {
        severityLevel = '21-40%: Moderate Disability';
        clinicalInterpretation = 'Patient experiences more pain and difficulty with sitting, lifting, and standing. Manual therapy, spinal adjustment, and targeted stabilization exercises indicated.';
      } else if (percentage >= 41 && percentage <= 60) {
        severityLevel = '41-60%: Severe Disability';
        clinicalInterpretation = 'Pain remains major problem. Activities of daily living are significantly impaired. Intensive active rehabilitation and modalities warranted.';
      } else if (percentage >= 61 && percentage <= 80) {
        severityLevel = '61-80%: Crippling Disability';
        clinicalInterpretation = 'Back pain impinges on all aspects of patient life. Supervised gentle decompression, physical therapy, and possible medical consultation required.';
      } else if (percentage > 80) {
        severityLevel = '81-100%: Bed-bound / Severe Limitation';
        clinicalInterpretation = 'Patient is either bed-bound or severely exaggerating symptoms. Immediate detailed neurological review required.';
      }

      return { rawScore, maxScore, percentage, severityLevel, clinicalInterpretation };
    },
  },

  NDI: {
    id: 'NDI',
    title: 'Neck Disability Index (NDI)',
    subtitle: 'Standardized assessment for cervical spine dysfunction and neck pain',
    clinicalDomain: 'Cervical Spine',
    description: 'Measures self-rated disability due to neck pain and cervicogenic headaches across 10 daily life activities.',
    mcidThreshold: 5, // 5 points or 10%
    sections: [
      {
        id: 'sec_pain',
        title: 'Section 1 — Neck Pain Intensity',
        options: [
          { score: 0, text: 'I have no pain at the moment.' },
          { score: 1, text: 'The pain is very mild at the moment.' },
          { score: 2, text: 'The pain is moderate at the moment.' },
          { score: 3, text: 'The pain is fairly severe at the moment.' },
          { score: 4, text: 'The pain is very severe at the moment.' },
          { score: 5, text: 'The pain is the worst imaginable at the moment.' },
        ],
      },
      {
        id: 'sec_personal',
        title: 'Section 2 — Personal Care (Washing, Dressing)',
        options: [
          { score: 0, text: 'I can look after myself normally without causing extra neck pain.' },
          { score: 1, text: 'I can look after myself normally but it causes extra pain.' },
          { score: 2, text: 'It is painful to look after myself and I am slow and careful.' },
          { score: 3, text: 'I need some help but manage most of my personal care.' },
          { score: 4, text: 'I need help every day in most aspects of self care.' },
          { score: 5, text: 'I cannot get dressed, I wash with difficulty and stay in bed.' },
        ],
      },
      {
        id: 'sec_lifting',
        title: 'Section 3 — Lifting',
        options: [
          { score: 0, text: 'I can lift heavy weights without extra neck pain.' },
          { score: 1, text: 'I can lift heavy weights but it gives extra neck pain.' },
          { score: 2, text: 'Pain prevents me from lifting heavy weights off the floor.' },
          { score: 3, text: 'Pain prevents me from lifting heavy weights, but light to medium is manageable.' },
          { score: 4, text: 'I can only lift very light weights.' },
          { score: 5, text: 'I cannot lift or carry anything at all.' },
        ],
      },
      {
        id: 'sec_reading',
        title: 'Section 4 — Reading / Screen Use',
        options: [
          { score: 0, text: 'I can read as much as I want with no neck pain.' },
          { score: 1, text: 'I can read as much as I want with slight pain in my neck.' },
          { score: 2, text: 'I can read as much as I want with moderate pain in my neck.' },
          { score: 3, text: 'I cannot read as much as I want because of moderate neck pain.' },
          { score: 4, text: 'I can hardly read at all because of severe neck pain.' },
          { score: 5, text: 'I cannot read at all.' },
        ],
      },
      {
        id: 'sec_headaches',
        title: 'Section 5 — Headaches',
        options: [
          { score: 0, text: 'I have no headaches at all.' },
          { score: 1, text: 'I have slight headaches which come infrequently.' },
          { score: 2, text: 'I have moderate headaches which come infrequently.' },
          { score: 3, text: 'I have moderate headaches which come frequently.' },
          { score: 4, text: 'I have severe headaches which come frequently.' },
          { score: 5, text: 'I have headaches almost all the time.' },
        ],
      },
      {
        id: 'sec_concentration',
        title: 'Section 6 — Concentration',
        options: [
          { score: 0, text: 'I can concentrate fully when I want to with no difficulty.' },
          { score: 1, text: 'I can concentrate fully with slight difficulty.' },
          { score: 2, text: 'I have a fair degree of difficulty in concentrating when I want to.' },
          { score: 3, text: 'I have a lot of difficulty in concentrating.' },
          { score: 4, text: 'I have a great deal of difficulty in concentrating.' },
          { score: 5, text: 'I cannot concentrate at all.' },
        ],
      },
      {
        id: 'sec_work',
        title: 'Section 7 — Work',
        options: [
          { score: 0, text: 'I can do as much work as I want to.' },
          { score: 1, text: 'I can only do my usual work, but no more.' },
          { score: 2, text: 'I can do most of my usual work, but no more.' },
          { score: 3, text: 'I cannot do my usual work.' },
          { score: 4, text: 'I can hardly do any work at all.' },
          { score: 5, text: 'I cannot do any work at all.' },
        ],
      },
      {
        id: 'sec_driving',
        title: 'Section 8 — Driving / Checking Blindspots',
        options: [
          { score: 0, text: 'I can drive my car without any neck pain.' },
          { score: 1, text: 'I can drive my car as long as I want with slight pain.' },
          { score: 2, text: 'I can drive my car as long as I want with moderate pain.' },
          { score: 3, text: 'I cannot drive my car as long as I want because of moderate pain.' },
          { score: 4, text: 'I can hardly drive at all because of severe neck pain.' },
          { score: 5, text: 'I cannot drive my car at all.' },
        ],
      },
      {
        id: 'sec_sleeping',
        title: 'Section 9 — Sleeping',
        options: [
          { score: 0, text: 'I have no trouble sleeping.' },
          { score: 1, text: 'My sleep is slightly disturbed (less than 1 hr sleepless).' },
          { score: 2, text: 'My sleep is mildly disturbed (1-2 hrs sleepless).' },
          { score: 3, text: 'My sleep is moderately disturbed (2-3 hrs sleepless).' },
          { score: 4, text: 'My sleep is greatly disturbed (3-5 hrs sleepless).' },
          { score: 5, text: 'My sleep is completely disturbed (5-7 hrs sleepless).' },
        ],
      },
      {
        id: 'sec_recreation',
        title: 'Section 10 — Recreation & Sports',
        options: [
          { score: 0, text: 'I am able to engage in all my recreation activities without neck pain.' },
          { score: 1, text: 'I am able to engage in all recreation activities with some neck pain.' },
          { score: 2, text: 'I am able to engage in most, but not all of my usual recreation activities.' },
          { score: 3, text: 'I am able to engage in only a few of my usual recreation activities.' },
          { score: 4, text: 'I can hardly do any recreation activities because of neck pain.' },
          { score: 5, text: 'I cannot do any recreation activities at all.' },
        ],
      },
    ],
    calculateScore: (answers) => {
      const keys = Object.keys(answers);
      const rawScore = keys.reduce((sum, k) => sum + (answers[k] ?? 0), 0);
      const maxScore = Math.max(keys.length * 5, 50);
      const percentage = Math.round((rawScore / maxScore) * 100);

      let severityLevel = '0-8%: No Disability';
      let clinicalInterpretation = 'Patient demonstrates minimal functional limitation. Cervical ROM and deep flexor stabilization exercises recommended.';

      if (rawScore >= 5 && rawScore <= 14) {
        severityLevel = '10-28%: Mild Disability';
        clinicalInterpretation = 'Mild limitation with reading/driving. Cervical manipulative therapy and postural retraining indicated.';
      } else if (rawScore >= 15 && rawScore <= 24) {
        severityLevel = '30-48%: Moderate Disability';
        clinicalInterpretation = 'Moderate disability. Significant reduction in work tolerance and cervical rotation. Active PT and CMT indicated.';
      } else if (rawScore >= 25 && rawScore <= 34) {
        severityLevel = '50-68%: Severe Disability';
        clinicalInterpretation = 'Severe disability. Marked sleep disturbance and cervicogenic symptoms.';
      } else if (rawScore >= 35) {
        severityLevel = '70-100%: Complete Disability';
        clinicalInterpretation = 'Complete disability. Patient bed-ridden or unable to sustain upright cervical posture.';
      }

      return { rawScore, maxScore, percentage, severityLevel, clinicalInterpretation };
    },
  },
};
