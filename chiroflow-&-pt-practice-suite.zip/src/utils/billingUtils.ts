export interface CptCodeDefinition {
  code: string;
  category: 'Chiropractic CMT' | 'PT Exercise' | 'PT Manual' | 'Modalities' | 'Evaluation & Management';
  description: string;
  defaultCharge: number;
  standardMedicareAllowed: number;
  unitTimeMinutes?: number;
  typicalModifiers: string[];
}

export const CPT_CODE_DATABASE: CptCodeDefinition[] = [
  {
    code: '98940',
    category: 'Chiropractic CMT',
    description: 'Chiropractic manipulative treatment (CMT); spinal, 1-2 regions',
    defaultCharge: 65,
    standardMedicareAllowed: 44.50,
    typicalModifiers: [],
  },
  {
    code: '98941',
    category: 'Chiropractic CMT',
    description: 'Chiropractic manipulative treatment (CMT); spinal, 3-4 regions',
    defaultCharge: 85,
    standardMedicareAllowed: 58.20,
    typicalModifiers: [],
  },
  {
    code: '98942',
    category: 'Chiropractic CMT',
    description: 'Chiropractic manipulative treatment (CMT); spinal, 5 regions (Full spine)',
    defaultCharge: 110,
    standardMedicareAllowed: 74.80,
    typicalModifiers: [],
  },
  {
    code: '98943',
    category: 'Chiropractic CMT',
    description: 'Chiropractic manipulative treatment (CMT); extraspinal, 1 or more regions',
    defaultCharge: 55,
    standardMedicareAllowed: 38.00,
    typicalModifiers: ['59'],
  },
  {
    code: '97110',
    category: 'PT Exercise',
    description: 'Therapeutic procedure, 1 or more areas, each 15 min; therapeutic exercises to develop strength and endurance',
    defaultCharge: 55,
    standardMedicareAllowed: 36.40,
    unitTimeMinutes: 15,
    typicalModifiers: ['GP', '59'],
  },
  {
    code: '97140',
    category: 'PT Manual',
    description: 'Manual therapy techniques (mobilization/manipulation, manual lymphatic drainage, manual traction), 15 min',
    defaultCharge: 52,
    standardMedicareAllowed: 34.10,
    unitTimeMinutes: 15,
    typicalModifiers: ['59', 'GP'],
  },
  {
    code: '97112',
    category: 'PT Exercise',
    description: 'Neuromuscular reeducation of movement, balance, coordination, kinesthetic sense, posture, and proprioception, 15 min',
    defaultCharge: 58,
    standardMedicareAllowed: 39.10,
    unitTimeMinutes: 15,
    typicalModifiers: ['GP'],
  },
  {
    code: '97530',
    category: 'PT Exercise',
    description: 'Therapeutic activities, direct (one-on-one) patient contact to improve functional performance, 15 min',
    defaultCharge: 65,
    standardMedicareAllowed: 42.60,
    unitTimeMinutes: 15,
    typicalModifiers: ['GP'],
  },
  {
    code: '97012',
    category: 'Modalities',
    description: 'Application of a modality to 1 or more areas; mechanical traction',
    defaultCharge: 40,
    standardMedicareAllowed: 24.30,
    typicalModifiers: ['GP'],
  },
  {
    code: '97014',
    category: 'Modalities',
    description: 'Application of a modality; electrical stimulation (unattended)',
    defaultCharge: 30,
    standardMedicareAllowed: 18.50,
    typicalModifiers: ['GP'],
  },
  {
    code: '97010',
    category: 'Modalities',
    description: 'Application of a modality; hot or cold packs',
    defaultCharge: 22,
    standardMedicareAllowed: 12.00,
    typicalModifiers: ['GY'],
  },
  {
    code: '99203',
    category: 'Evaluation & Management',
    description: 'Office or other outpatient visit for evaluation and management of a new patient, 30-44 min',
    defaultCharge: 150,
    standardMedicareAllowed: 115.00,
    typicalModifiers: ['25'],
  },
  {
    code: '99213',
    category: 'Evaluation & Management',
    description: 'Office or other outpatient visit for evaluation and management of an established patient, 20-29 min',
    defaultCharge: 95,
    standardMedicareAllowed: 78.40,
    typicalModifiers: ['25'],
  },
  {
    code: '97161',
    category: 'Evaluation & Management',
    description: 'Physical therapy evaluation: low complexity, 20 min',
    defaultCharge: 135,
    standardMedicareAllowed: 95.00,
    typicalModifiers: ['GP'],
  },
  {
    code: '97162',
    category: 'Evaluation & Management',
    description: 'Physical therapy evaluation: moderate complexity, 30 min',
    defaultCharge: 170,
    standardMedicareAllowed: 120.00,
    typicalModifiers: ['GP'],
  },
  {
    code: '97164',
    category: 'Evaluation & Management',
    description: 'Physical therapy re-evaluation of established patient, 20 min',
    defaultCharge: 110,
    standardMedicareAllowed: 82.00,
    typicalModifiers: ['GP'],
  },
];

export interface ScrubResult {
  passed: boolean;
  warnings: string[];
  errors: string[];
}

export function scrubClaim(claimLines: { cptCode: string; modifier?: string; units: number }[]): ScrubResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  const codes = claimLines.map(l => l.cptCode);
  const hasChiroCmt = codes.some(c => ['98940', '98941', '98942'].includes(c));
  const hasManualTherapy = codes.includes('97140');
  const manualLine = claimLines.find(l => l.cptCode === '97140');

  // CCI Edit Check: 97140 billed with 98940-98942 requires modifier -59 to indicate distinct anatomical region
  if (hasChiroCmt && hasManualTherapy) {
    if (!manualLine?.modifier || !manualLine.modifier.includes('59')) {
      errors.push('CCI Edit conflict: CPT 97140 (Manual Therapy) billed on same date as Chiropractic CMT requires Modifier -59 to attest separate anatomical region.');
    }
  }

  // 8-minute rule check for timed codes
  const timedCodes = ['97110', '97140', '97112', '97530'];
  const totalTimedUnits = claimLines
    .filter(l => timedCodes.includes(l.cptCode))
    .reduce((sum, l) => sum + (l.units || 1), 0);

  if (totalTimedUnits > 4) {
    warnings.push(`High timed unit count: ${totalTimedUnits} units (${totalTimedUnits * 15} minutes) billed. Ensure documentation justifies > 1 hour one-on-one therapy.`);
  }

  if (claimLines.length === 0) {
    errors.push('A valid claim must contain at least 1 CPT service line item.');
  }

  return {
    passed: errors.length === 0,
    errors,
    warnings,
  };
}
