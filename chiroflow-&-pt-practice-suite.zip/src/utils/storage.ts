import { Patient, Appointment, Claim, SoapNote, OutcomeMeasure } from '../types';
import { MOCK_PATIENTS, MOCK_APPOINTMENTS, MOCK_CLAIMS, MOCK_SOAP_NOTES, MOCK_OUTCOMES } from '../data/mockData';

const KEYS = {
  PATIENTS: 'chiroflow_patients_v1',
  APPOINTMENTS: 'chiroflow_appointments_v1',
  CLAIMS: 'chiroflow_claims_v1',
  SOAP_NOTES: 'chiroflow_soaps_v1',
  OUTCOMES: 'chiroflow_outcomes_v1',
};

export function loadPatients(): Patient[] {
  try {
    const raw = localStorage.getItem(KEYS.PATIENTS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  savePatients(MOCK_PATIENTS);
  return MOCK_PATIENTS;
}

export function savePatients(patients: Patient[]): void {
  try {
    localStorage.setItem(KEYS.PATIENTS, JSON.stringify(patients));
  } catch (e) {
    console.error(e);
  }
}

export function loadAppointments(): Appointment[] {
  try {
    const raw = localStorage.getItem(KEYS.APPOINTMENTS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  saveAppointments(MOCK_APPOINTMENTS);
  return MOCK_APPOINTMENTS;
}

export function saveAppointments(appointments: Appointment[]): void {
  try {
    localStorage.setItem(KEYS.APPOINTMENTS, JSON.stringify(appointments));
  } catch (e) {
    console.error(e);
  }
}

export function loadClaims(): Claim[] {
  try {
    const raw = localStorage.getItem(KEYS.CLAIMS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  saveClaims(MOCK_CLAIMS);
  return MOCK_CLAIMS;
}

export function saveClaims(claims: Claim[]): void {
  try {
    localStorage.setItem(KEYS.CLAIMS, JSON.stringify(claims));
  } catch (e) {
    console.error(e);
  }
}

export function loadSoapNotes(): SoapNote[] {
  try {
    const raw = localStorage.getItem(KEYS.SOAP_NOTES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  saveSoapNotes(MOCK_SOAP_NOTES);
  return MOCK_SOAP_NOTES;
}

export function saveSoapNotes(soaps: SoapNote[]): void {
  try {
    localStorage.setItem(KEYS.SOAP_NOTES, JSON.stringify(soaps));
  } catch (e) {
    console.error(e);
  }
}

export function loadOutcomes(): OutcomeMeasure[] {
  try {
    const raw = localStorage.getItem(KEYS.OUTCOMES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error(e);
  }
  saveOutcomes(MOCK_OUTCOMES);
  return MOCK_OUTCOMES;
}

export function saveOutcomes(outcomes: OutcomeMeasure[]): void {
  try {
    localStorage.setItem(KEYS.OUTCOMES, JSON.stringify(outcomes));
  } catch (e) {
    console.error(e);
  }
}

export function resetClinicData(): void {
  savePatients(MOCK_PATIENTS);
  saveAppointments(MOCK_APPOINTMENTS);
  saveClaims(MOCK_CLAIMS);
  saveSoapNotes(MOCK_SOAP_NOTES);
  saveOutcomes(MOCK_OUTCOMES);
}
