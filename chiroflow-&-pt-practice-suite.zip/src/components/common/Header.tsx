import React from 'react';
import { Calendar, Plus, RefreshCw, Activity, UserCheck } from 'lucide-react';
import { CLINIC_INFO } from '../../data/mockData';
import { Provider } from '../../types';

interface HeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  selectedDate: string;
  onDateChange: (date: string) => void;
  onNewAppointmentClick: () => void;
  onResetData: () => void;
  selectedProviderId: string;
  onProviderChange: (id: string) => void;
  providers: Provider[];
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  selectedDate,
  onDateChange,
  onNewAppointmentClick,
  onResetData,
  selectedProviderId,
  onProviderChange,
  providers,
}) => {
  const tabs = [
    { id: 'schedule', label: 'Schedule & Rooms' },
    { id: 'billing', label: 'Billing & Claims' },
    { id: 'outcomes', label: 'Outcomes & ROM' },
    { id: 'telehealth', label: 'Telehealth Virtual Rehab' },
    { id: 'patients', label: 'Patient Charts & SOAP' },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      {/* Strict Top Bar Contract: 3 Zones */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Single text element Brand Zone */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-sm tracking-tight shadow-xs">
              CF
            </div>
            <a 
              href="#" 
              onClick={(e) => { e.preventDefault(); onTabChange('schedule'); }}
              className="text-lg font-bold tracking-tight text-slate-900 hover:text-teal-700 transition-colors"
            >
              ChiroFlow & PT
            </a>
          </div>

          {/* Zone 2: 4-6 Clean text navigation links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    isActive
                      ? 'text-teal-800 bg-teal-50 border-b-2 border-teal-600 rounded-b-none'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary actions & filters */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Quick Provider Filter */}
            <div className="hidden md:flex items-center text-xs text-slate-600 border border-slate-200 rounded-md px-2 py-1.5 bg-slate-50">
              <UserCheck className="w-3.5 h-3.5 mr-1.5 text-slate-400" />
              <select
                value={selectedProviderId}
                onChange={(e) => onProviderChange(e.target.value)}
                className="bg-transparent border-none text-xs font-medium text-slate-700 focus:outline-none cursor-pointer"
              >
                <option value="all">All Practitioners (3)</option>
                {providers.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}, {p.credentials}
                  </option>
                ))}
              </select>
            </div>

            {/* Date Selector */}
            <div className="flex items-center text-xs text-slate-600 border border-slate-200 rounded-md px-2.5 py-1.5 bg-white">
              <Calendar className="w-3.5 h-3.5 mr-1.5 text-slate-400" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => onDateChange(e.target.value)}
                className="bg-transparent border-none text-xs font-mono tabular-nums text-slate-800 focus:outline-none cursor-pointer"
              />
            </div>

            {/* Quick Action Button */}
            <button
              onClick={onNewAppointmentClick}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-teal-600 rounded-md hover:bg-teal-700 transition-colors shadow-xs whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Appointment</span>
              <span className="sm:hidden">Book</span>
            </button>

            {/* Reset Seed Demo Data */}
            <button
              onClick={onResetData}
              title="Reset demonstration data"
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="lg:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-100 no-scrollbar">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
                  isActive
                    ? 'text-teal-700 bg-teal-50 font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
