import React, { useState } from 'react';
import { SpineSubluxation } from '../../types';
import { Check, X, Trash2, Plus } from 'lucide-react';

interface SpineInteractiveModelProps {
  subluxations: SpineSubluxation[];
  onChange: (subluxations: SpineSubluxation[]) => void;
  readOnly?: boolean;
}

export const SpineInteractiveModel: React.FC<SpineInteractiveModelProps> = ({
  subluxations,
  onChange,
  readOnly = false,
}) => {
  const [selectedSegment, setSelectedSegment] = useState<string>('L4');
  const [listing, setListing] = useState<string>('PR');
  const [technique, setTechnique] = useState<'Diversified' | 'Activator' | 'Drop Table' | 'Gonstead' | 'Flexion-Distraction'>('Diversified');
  const [tenderness, setTenderness] = useState<0 | 1 | 2 | 3>(2);

  const spineSections = [
    {
      name: 'Cervical Spine (C1 - C7)',
      segments: ['C1 (Atlas)', 'C2 (Axis)', 'C3', 'C4', 'C5', 'C6', 'C7'],
      color: '#0d9488',
    },
    {
      name: 'Thoracic Spine (T1 - T12)',
      segments: ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'],
      color: '#0284c7',
    },
    {
      name: 'Lumbar Spine (L1 - L5)',
      segments: ['L1', 'L2', 'L3', 'L4', 'L5'],
      color: '#7c3aed',
    },
    {
      name: 'Pelvis & Sacroiliac',
      segments: ['Sacrum', 'Left SI Joint', 'Right SI Joint'],
      color: '#e11d48',
    },
  ];

  const handleToggleSegment = (seg: string) => {
    if (readOnly) return;
    const cleanSeg = seg.split(' ')[0];
    setSelectedSegment(cleanSeg);

    // If already exists, populate its details
    const existing = subluxations.find(s => s.segment === cleanSeg);
    if (existing) {
      setListing(existing.listing);
      setTechnique(existing.technique);
      setTenderness(existing.tenderness);
    }
  };

  const handleApplyListing = () => {
    if (readOnly) return;
    const filtered = subluxations.filter(s => s.segment !== selectedSegment);
    const updated: SpineSubluxation = {
      segment: selectedSegment,
      listing,
      technique,
      tenderness,
    };
    onChange([...filtered, updated]);
  };

  const handleRemoveListing = (seg: string) => {
    if (readOnly) return;
    onChange(subluxations.filter(s => s.segment !== seg));
  };

  return (
    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
      
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div>
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
            Interactive Spine & Vertebral Subluxation Map
          </h4>
          <p className="text-[11px] text-slate-500">
            Select vertebral segments to record fixation listings, palpation tenderness, and CMT technique
          </p>
        </div>
        <span className="text-xs font-mono font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
          {subluxations.length} Segments Tagged
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Left: Interactive Spine Column Vertebrae Buttons */}
        <div className="lg:col-span-7 space-y-3">
          {spineSections.map((sec) => (
            <div key={sec.name} className="space-y-1.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                {sec.name}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {sec.segments.map((segFull) => {
                  const segCode = segFull.split(' ')[0];
                  const activeSub = subluxations.find(s => s.segment === segCode);
                  const isCurrentSelected = selectedSegment === segCode;

                  return (
                    <button
                      key={segFull}
                      type="button"
                      onClick={() => handleToggleSegment(segFull)}
                      className={`px-2.5 py-1 text-xs rounded-md font-mono font-semibold transition-all flex items-center gap-1 ${
                        activeSub
                          ? 'bg-rose-500 text-white shadow-xs'
                          : isCurrentSelected
                          ? 'bg-teal-700 text-white ring-2 ring-teal-400'
                          : 'bg-white text-slate-700 border border-slate-300 hover:border-teal-500'
                      }`}
                    >
                      <span>{segFull}</span>
                      {activeSub && (
                        <span className="text-[9px] bg-rose-700/80 px-1 py-0.2 rounded">
                          {activeSub.listing}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Right: Segment Listing Editor */}
        {!readOnly && (
          <div className="lg:col-span-5 bg-white p-3.5 rounded-lg border border-slate-200 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="text-xs font-bold text-slate-900">
                Segment Listing: <span className="font-mono text-teal-700">{selectedSegment}</span>
              </span>
              {subluxations.some(s => s.segment === selectedSegment) && (
                <button
                  type="button"
                  onClick={() => handleRemoveListing(selectedSegment)}
                  className="text-xs text-rose-600 hover:underline flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" /> Clear
                </button>
              )}
            </div>

            {/* Listing Selection */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Subluxation / Fixation Listing
              </label>
              <div className="grid grid-cols-3 gap-1 text-xs">
                {['PR', 'PL', 'PRS', 'PLS', 'Subluxated', 'Fixated'].map((l) => (
                  <button
                    key={l}
                    type="button"
                    onClick={() => setListing(l)}
                    className={`py-1 px-1.5 rounded border text-center font-mono ${
                      listing === l
                        ? 'bg-teal-50 border-teal-500 text-teal-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* CMT Technique */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                CMT Technique Delivered
              </label>
              <select
                value={technique}
                onChange={(e) => setTechnique(e.target.value as any)}
                className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white text-slate-800"
              >
                <option value="Diversified">Diversified (HVLA Manual)</option>
                <option value="Drop Table">Thompson Drop Table</option>
                <option value="Activator">Activator Instrument Assisted</option>
                <option value="Gonstead">Gonstead Specific</option>
                <option value="Flexion-Distraction">Cox Flexion-Distraction</option>
              </select>
            </div>

            {/* Palpation Tenderness */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Palpation Tenderness Grade: <span className="font-mono font-bold text-slate-900">{tenderness}/3</span>
              </label>
              <div className="grid grid-cols-4 gap-1 text-[11px]">
                {[
                  { val: 0, label: '0 None' },
                  { val: 1, label: '1+ Mild' },
                  { val: 2, label: '2+ Mod' },
                  { val: 3, label: '3+ Severe' },
                ].map(t => (
                  <button
                    key={t.val}
                    type="button"
                    onClick={() => setTenderness(t.val as any)}
                    className={`py-1 rounded border text-center ${
                      tenderness === t.val
                        ? 'bg-rose-50 border-rose-400 text-rose-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={handleApplyListing}
              className="w-full py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-md transition-colors shadow-xs flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Save {selectedSegment} Listing
            </button>
          </div>
        )}
      </div>

      {/* Currently Charted Subluxations Summary Pill List */}
      <div className="pt-2 border-t border-slate-200 flex flex-wrap gap-2 text-xs">
        <span className="font-semibold text-slate-700 py-1">Charted Today:</span>
        {subluxations.length === 0 ? (
          <span className="text-slate-400 py-1 italic">No segments adjusted/tagged yet.</span>
        ) : (
          subluxations.map(s => (
            <span
              key={s.segment}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white border border-slate-300 rounded-md text-slate-800 font-mono text-xs shadow-xs"
            >
              <span className="font-bold text-teal-800">{s.segment}</span>
              <span>({s.listing})</span>
              <span className="text-[10px] text-slate-500 font-sans">{s.technique}</span>
              {!readOnly && (
                <button
                  type="button"
                  onClick={() => handleRemoveListing(s.segment)}
                  className="text-slate-400 hover:text-rose-600 ml-1"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </span>
          ))
        )}
      </div>
    </div>
  );
};
