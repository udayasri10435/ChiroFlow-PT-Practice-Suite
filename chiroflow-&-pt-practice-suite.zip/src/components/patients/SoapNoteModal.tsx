import React, { useState } from 'react';
import { X, Check, Save, Printer, Lock, FileText, Activity, ShieldCheck } from 'lucide-react';
import { SoapNote, Patient, Provider, SpineSubluxation } from '../../types';
import { SpineInteractiveModel } from './SpineInteractiveModel';
import { CPT_CODE_DATABASE } from '../../utils/billingUtils';

interface SoapNoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (note: SoapNote) => void;
  patient?: Patient;
  provider?: Provider;
  appointmentId?: string;
  existingNote?: SoapNote;
}

export const SoapNoteModal: React.FC<SoapNoteModalProps> = ({
  isOpen,
  onClose,
  onSave,
  patient,
  provider,
  appointmentId = `apt-${Date.now()}`,
  existingNote,
}) => {
  const [activeTab, setActiveTab] = useState<'subjective' | 'objective' | 'assessment' | 'plan'>('subjective');

  // Subjective
  const [chiefComplaint, setChiefComplaint] = useState(
    existingNote?.subjective.chiefComplaint ||
    `Care plan visit for ${patient?.diagnoses[0]?.description || 'lumbar mechanical dysfunction'}`
  );
  const [vasScore, setVasScore] = useState(existingNote?.subjective.vasScore ?? patient?.currentPainVas ?? 3);
  const [symptomsDescription, setSymptomsDescription] = useState(
    existingNote?.subjective.symptomsDescription ||
    'Patient reports localized achiness and morning stiffness with mild tingling in posterior thigh. Pain reduces after light movement.'
  );
  const [functionalLimitations, setFunctionalLimitations] = useState(
    existingNote?.subjective.functionalLimitations ||
    'Difficulty standing > 30 minutes without needing to lean or sit. Walking up to 1 mile manageable.'
  );
  const [aggravatingFactors, setAggravatingFactors] = useState(
    existingNote?.subjective.aggravatingFactors || 'Prolonged sitting at desk, bending forward to tie shoes.'
  );
  const [relievingFactors, setRelievingFactors] = useState(
    existingNote?.subjective.relievingFactors || 'Prone press-up extension exercises, application of ice.'
  );

  // Objective
  const [subluxations, setSubluxations] = useState<SpineSubluxation[]>(
    existingNote?.objective.subluxations || [
      { segment: 'L4', listing: 'PR', technique: 'Diversified', tenderness: 2 },
      { segment: 'L5', listing: 'RP', technique: 'Drop Table', tenderness: 1 },
      { segment: 'Left SI', listing: 'PI', technique: 'Drop Table', tenderness: 2 },
    ]
  );
  const [muscleSpasmGrade, setMuscleSpasmGrade] = useState<'0 Normal' | '1+ Mild' | '2+ Moderate' | '3+ Severe'>(
    existingNote?.objective.muscleSpasmGrade || '1+ Mild'
  );
  const [palpationNotes, setPalpationNotes] = useState(
    existingNote?.objective.palpationNotes ||
    'Palpable taut bands in left erector spinae and quadratus lumborum. Tenderness at left L4-L5 facet margin.'
  );
  const [specialTests, setSpecialTests] = useState(
    existingNote?.objective.specialTests ||
    'Straight Leg Raise negative bilaterally (75°). Kemp test negative bilaterally. DTRs 2+ symmetrical.'
  );

  // Assessment
  const [clinicalProgress, setClinicalProgress] = useState<'Significant Improvement' | 'Moderate Progress' | 'Stable / Plateau' | 'Acute Flare-up'>(
    existingNote?.assessment.clinicalProgress || 'Significant Improvement'
  );
  const [prognosis, setPrognosis] = useState(
    existingNote?.assessment.prognosis || 'Good. Patient compliant with ergonomic instructions and active rehabilitation.'
  );
  const [treatmentTolerance, setTreatmentTolerance] = useState(
    existingNote?.assessment.treatmentTolerance || 'Patient tolerated spinal manipulative treatment and therapeutic modalities with zero adverse reactions.'
  );

  // Plan
  const [selectedCpts, setSelectedCpts] = useState<string[]>(
    existingNote?.plan.cptCodes || ['98941', '97140', '97110']
  );
  const [spinalAdjustments, setSpinalAdjustments] = useState(
    existingNote?.plan.spinalAdjustments ||
    'High velocity low amplitude (HVLA) Diversified CMT delivered to L4 and L5. Sacroiliac drop table mobilization applied to left pelvis.'
  );
  const [homeExercises, setHomeExercises] = useState(
    existingNote?.plan.homeExercisesPrescribed ||
    'McKenzie prone lumbar press-ups 8 reps 3x/day, Bird-dog 3x10 holds, side-lying clamshells.'
  );
  const [frequencyAndDuration, setFrequencyAndDuration] = useState(
    existingNote?.plan.frequencyAndDuration || '2 visits per week for 3 weeks, then re-evaluation.'
  );
  const [nextVisitDate, setNextVisitDate] = useState('2026-10-02');
  const [isSigned, setIsSigned] = useState(existingNote?.signed || false);

  if (!isOpen) return null;

  const handleToggleCpt = (code: string) => {
    if (selectedCpts.includes(code)) {
      setSelectedCpts(selectedCpts.filter(c => c !== code));
    } else {
      setSelectedCpts([...selectedCpts, code]);
    }
  };

  const handleSaveNote = (signNow: boolean) => {
    const finalNote: SoapNote = {
      id: existingNote?.id || `soap-${Date.now()}`,
      appointmentId,
      patientId: patient?.id || '',
      providerId: provider?.id || '',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
      subjective: {
        chiefComplaint,
        vasScore,
        symptomsDescription,
        functionalLimitations,
        aggravatingFactors,
        relievingFactors,
      },
      objective: {
        subluxations,
        roms: [
          { region: 'Lumbar', movement: 'Flexion', measuredDegrees: 68, normalDegrees: 80, painOnMotion: false },
          { region: 'Lumbar', movement: 'Extension', measuredDegrees: 20, normalDegrees: 25, painOnMotion: false },
        ],
        postureFindings: 'Normalizing weight distribution, reduced antalgic lean.',
        palpationNotes,
        muscleSpasmGrade,
        specialTests,
      },
      assessment: {
        clinicalProgress,
        prognosis,
        treatmentTolerance,
        icd10Codes: patient?.diagnoses.map(d => d.code) || ['M51.26', 'M54.16'],
      },
      plan: {
        cptCodes: selectedCpts,
        spinalAdjustments,
        modalitiesDelivered: ['Manual therapy (97140)', 'Therapeutic exercise (97110)'],
        homeExercisesPrescribed: homeExercises,
        frequencyAndDuration,
        nextVisitDate,
      },
      signed: signNow || isSigned,
      signedBy: signNow || isSigned ? `${provider?.name}, ${provider?.credentials}` : undefined,
      signedAt: signNow ? new Date().toISOString() : existingNote?.signedAt,
    };

    onSave(finalNote);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-4xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-teal-100 text-teal-800 rounded">
                SOAP Encounter Documentation
              </span>
              <h2 className="text-sm font-bold text-slate-900">
                {patient?.lastName}, {patient?.firstName} ({patient?.mrn})
              </h2>
            </div>
            {/* Zero-Pill unboxed metadata */}
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>Date: {new Date().toISOString().split('T')[0]}</span>
              <span aria-hidden="true">·</span>
              <span>Attending: {provider?.name}, {provider?.credentials}</span>
              <span aria-hidden="true">·</span>
              <span>Insurance: {patient?.insurance.payerName}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isSigned && (
              <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-1 rounded font-semibold flex items-center gap-1 border border-emerald-200">
                <Lock className="w-3.5 h-3.5" /> Signed & Locked
              </span>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* SOAP Section Tabs */}
        <div className="px-6 py-2 bg-slate-100/80 border-b border-slate-200 flex items-center gap-2 shrink-0">
          {[
            { id: 'subjective', letter: 'S', label: 'Subjective (Pain & Symptoms)' },
            { id: 'objective', letter: 'O', label: 'Objective (Spine Model & ROM)' },
            { id: 'assessment', letter: 'A', label: 'Assessment & Progress' },
            { id: 'plan', letter: 'P', label: 'Plan & Billing CPTs' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'bg-white text-teal-800 shadow-xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-teal-600 text-white font-mono text-[10px] flex items-center justify-center font-bold">
                {tab.letter}
              </span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Form Body Scrollable Area */}
        <div className="p-6 overflow-y-auto space-y-4">
          
          {/* Section S: Subjective */}
          {activeTab === 'subjective' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Chief Complaint / Reason for Encounter
                </label>
                <input
                  type="text"
                  value={chiefComplaint}
                  onChange={(e) => setChiefComplaint(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 focus:ring-1 focus:ring-teal-500"
                />
              </div>

              {/* VAS Pain Slider */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-800">
                    Patient VAS / NPRS Pain Rating: <span className="font-bold font-mono text-slate-900">{vasScore} / 10</span>
                  </span>
                  <span className="text-slate-500 font-mono text-[11px]">
                    (Previous: {patient?.currentPainVas ?? 3}/10)
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={vasScore}
                  onChange={(e) => setVasScore(Number(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg cursor-pointer accent-teal-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Symptoms & Narrative Since Last Visit
                </label>
                <textarea
                  rows={2}
                  value={symptomsDescription}
                  onChange={(e) => setSymptomsDescription(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg text-slate-800 focus:ring-1 focus:ring-teal-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Functional ADL Limitations
                  </label>
                  <textarea
                    rows={2}
                    value={functionalLimitations}
                    onChange={(e) => setFunctionalLimitations(e.target.value)}
                    className="w-full p-2 text-xs border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Aggravating & Relieving Factors
                  </label>
                  <textarea
                    rows={2}
                    value={aggravatingFactors}
                    onChange={(e) => setAggravatingFactors(e.target.value)}
                    className="w-full p-2 text-xs border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Section O: Objective */}
          {activeTab === 'objective' && (
            <div className="space-y-5">
              {/* Embedded Interactive Spine Subluxation Chart */}
              <SpineInteractiveModel
                subluxations={subluxations}
                onChange={setSubluxations}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Paraspinal Muscle Spasm Grade
                  </label>
                  <select
                    value={muscleSpasmGrade}
                    onChange={(e) => setMuscleSpasmGrade(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white text-slate-800"
                  >
                    <option value="0 Normal">0 Normal (No hypertonicity)</option>
                    <option value="1+ Mild">1+ Mild (Localized taut fibers)</option>
                    <option value="2+ Moderate">2+ Moderate (Prominent guarding, tender)</option>
                    <option value="3+ Severe">3+ Severe (Rigid board-like contracture)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Orthopedic & Neurological Provocation Tests
                  </label>
                  <input
                    type="text"
                    value={specialTests}
                    onChange={(e) => setSpecialTests(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Soft Tissue & Palpation Findings
                </label>
                <textarea
                  rows={2}
                  value={palpationNotes}
                  onChange={(e) => setPalpationNotes(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg text-slate-800"
                />
              </div>
            </div>
          )}

          {/* Section A: Assessment */}
          {activeTab === 'assessment' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Overall Clinical Trajectory / Progress
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    'Significant Improvement',
                    'Moderate Progress',
                    'Stable / Plateau',
                    'Acute Flare-up',
                  ].map(prog => (
                    <button
                      key={prog}
                      type="button"
                      onClick={() => setClinicalProgress(prog as any)}
                      className={`p-2.5 rounded-lg border text-xs font-semibold text-center transition-colors ${
                        clinicalProgress === prog
                          ? 'bg-teal-50 border-teal-500 text-teal-900 shadow-xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {prog}
                    </button>
                  ))}
                </div>
              </div>

              {/* Linked ICD-10 Diagnoses */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <span className="text-xs font-bold text-slate-900 block mb-1">
                  Active Linked ICD-10 Diagnoses:
                </span>
                <div className="space-y-1">
                  {patient?.diagnoses.map(d => (
                    <div key={d.code} className="text-xs text-slate-700 flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                        {d.code}
                      </span>
                      <span>{d.description}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Prognosis & Functional Capacity
                </label>
                <textarea
                  rows={2}
                  value={prognosis}
                  onChange={(e) => setPrognosis(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tolerance to Treatment
                </label>
                <input
                  type="text"
                  value={treatmentTolerance}
                  onChange={(e) => setTreatmentTolerance(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800"
                />
              </div>
            </div>
          )}

          {/* Section P: Plan & Billing */}
          {activeTab === 'plan' && (
            <div className="space-y-4">
              
              {/* CPT Codes Multi-select */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Select CPT Codes Performed Today (Auto-adds to Superbill):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {CPT_CODE_DATABASE.slice(0, 9).map(cpt => {
                    const isSelected = selectedCpts.includes(cpt.code);
                    return (
                      <div
                        key={cpt.code}
                        onClick={() => handleToggleCpt(cpt.code)}
                        className={`p-2 rounded-lg border text-xs cursor-pointer transition-colors flex items-center justify-between ${
                          isSelected
                            ? 'bg-teal-50 border-teal-500 text-teal-950 font-bold'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div>
                          <span className="font-mono">{cpt.code}</span>
                          <p className="text-[10px] text-slate-500 font-normal truncate max-w-[140px]">
                            {cpt.description}
                          </p>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-teal-600 shrink-0" />}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Adjustments & Procedures Narrative
                </label>
                <textarea
                  rows={2}
                  value={spinalAdjustments}
                  onChange={(e) => setSpinalAdjustments(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Home Rehabilitation Exercises Prescribed
                </label>
                <textarea
                  rows={2}
                  value={homeExercises}
                  onChange={(e) => setHomeExercises(e.target.value)}
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg text-slate-800"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Frequency & Duration of Care
                  </label>
                  <input
                    type="text"
                    value={frequencyAndDuration}
                    onChange={(e) => setFrequencyAndDuration(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Next Follow-Up Appointment Date
                  </label>
                  <input
                    type="date"
                    value={nextVisitDate}
                    onChange={(e) => setNextVisitDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono border border-slate-300 rounded-lg text-slate-800"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-200 rounded-lg"
          >
            Cancel
          </button>
          
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleSaveNote(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Save Draft Note
            </button>

            <button
              type="button"
              onClick={() => handleSaveNote(true)}
              className="px-5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors shadow-xs inline-flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" /> Sign & Lock SOAP Note
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
