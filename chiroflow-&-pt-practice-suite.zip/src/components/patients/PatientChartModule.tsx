import React, { useState } from 'react';
import { 
  User, 
  Search, 
  Plus, 
  FileText, 
  Phone, 
  Mail, 
  MapPin, 
  Shield, 
  Activity, 
  Calendar, 
  DollarSign, 
  Clock, 
  CheckCircle2,
  Lock,
  ChevronRight
} from 'lucide-react';
import { Patient, Provider, SoapNote } from '../../types';
import { SoapNoteModal } from './SoapNoteModal';
import { SpineInteractiveModel } from './SpineInteractiveModel';

interface PatientChartModuleProps {
  patients: Patient[];
  providers: Provider[];
  soapNotes: SoapNote[];
  onSaveSoapNote: (note: SoapNote) => void;
  selectedPatientId?: string;
  onSelectPatient: (id: string) => void;
  onOpenNewClaimForPatient: (patientId: string) => void;
  onOpenOutcomeForPatient: (patientId: string) => void;
}

export const PatientChartModule: React.FC<PatientChartModuleProps> = ({
  patients,
  providers,
  soapNotes,
  onSaveSoapNote,
  selectedPatientId,
  onSelectPatient,
  onOpenNewClaimForPatient,
  onOpenOutcomeForPatient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [phaseFilter, setPhaseFilter] = useState<string>('all');
  const [isSoapModalOpen, setIsSoapModalOpen] = useState(false);
  const [selectedSoapToView, setSelectedSoapToView] = useState<SoapNote | null>(null);

  const activePatId = selectedPatientId || patients[0]?.id || '';
  const currentPatient = patients.find(p => p.id === activePatId) || patients[0];

  const filteredPatients = patients.filter(p => {
    if (phaseFilter !== 'all' && p.carePlanPhase !== phaseFilter) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const fullName = `${p.firstName} ${p.lastName}`.toLowerCase();
      const mrn = p.mrn.toLowerCase();
      const phone = p.phone.toLowerCase();
      return fullName.includes(term) || mrn.includes(term) || phone.includes(term);
    }
    return true;
  });

  const patientSoapNotes = soapNotes.filter(n => n.patientId === currentPatient?.id);
  const primaryProvider = providers.find(p => p.id === currentPatient?.primaryProviderId) || providers[0];

  return (
    <div className="space-y-6">
      
      {/* Top Split Layout: Patient Directory Sidebar + Comprehensive Patient Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (4 cols): Patient Master Directory */}
        <div className="lg:col-span-4 space-y-3">
          
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Patient Directory ({patients.length})
              </h3>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name, MRN, phone..."
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            {/* Care Phase Filter */}
            <select
              value={phaseFilter}
              onChange={(e) => setPhaseFilter(e.target.value)}
              className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded-md text-slate-700 bg-white"
            >
              <option value="all">All Care Phases</option>
              <option value="Acute Relief">Acute Relief</option>
              <option value="Corrective Care">Corrective Care</option>
              <option value="Strengthening Rehab">Strengthening Rehab</option>
              <option value="Maintenance / Wellness">Maintenance / Wellness</option>
            </select>
          </div>

          {/* Patient Cards List */}
          <div className="space-y-2 max-h-[750px] overflow-y-auto pr-1">
            {filteredPatients.map((pat) => {
              const isSelected = pat.id === currentPatient?.id;
              return (
                <div
                  key={pat.id}
                  onClick={() => onSelectPatient(pat.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-teal-50/80 border-teal-500 text-teal-950 shadow-xs'
                      : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">
                        {pat.lastName}, {pat.firstName}
                      </h4>
                      {/* Zero-Pill unboxed metadata */}
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono mt-0.5">
                        <span>{pat.mrn}</span>
                        <span aria-hidden="true">·</span>
                        <span>DOB: {pat.dob}</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                      VAS {pat.currentPainVas}/10
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 mt-1.5 truncate">
                    {pat.diagnoses[0]?.description}
                  </p>

                  <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
                    <span>{pat.carePlanPhase}</span>
                    <span className="font-mono">{pat.totalVisits} visits completed</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (8 cols): Clinical EHR Chart for Selected Patient */}
        {currentPatient && (
          <div className="lg:col-span-8 space-y-6">
            
            {/* Patient Header Card */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-xl bg-teal-600 text-white font-bold text-lg flex items-center justify-center shadow-xs">
                    {currentPatient.firstName[0]}{currentPatient.lastName[0]}
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      {currentPatient.lastName}, {currentPatient.firstName}
                    </h2>
                    {/* Zero-Pill unboxed metadata */}
                    <div className="flex items-center gap-2 text-xs text-slate-500 font-mono mt-0.5">
                      <span>{currentPatient.mrn}</span>
                      <span aria-hidden="true">·</span>
                      <span>DOB: {currentPatient.dob} ({currentPatient.gender})</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-teal-700 font-semibold">{currentPatient.carePlanPhase}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => { setSelectedSoapToView(null); setIsSoapModalOpen(true); }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" /> + New SOAP Note
                  </button>

                  <button
                    onClick={() => onOpenNewClaimForPatient(currentPatient.id)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors"
                  >
                    <DollarSign className="w-3.5 h-3.5" /> Create Claim
                  </button>
                </div>
              </div>

              {/* Demographics & Insurance Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100 text-xs">
                <div>
                  <span className="text-slate-400 font-semibold text-[10px] uppercase block">Contact</span>
                  <span className="text-slate-800">{currentPatient.phone}</span>
                  <span className="text-slate-500 text-[11px] block truncate">{currentPatient.email}</span>
                </div>

                <div>
                  <span className="text-slate-400 font-semibold text-[10px] uppercase block">Primary Insurance</span>
                  <span className="text-slate-800 font-medium">{currentPatient.insurance.payerName}</span>
                  <span className="font-mono text-slate-500 text-[11px] block">Pol: {currentPatient.insurance.policyId}</span>
                </div>

                <div>
                  <span className="text-slate-400 font-semibold text-[10px] uppercase block">Copay & Deductible</span>
                  <span className="font-mono font-bold text-slate-900">${currentPatient.insurance.copayAmount} Copay</span>
                  <span className="text-slate-500 font-mono text-[11px] block">${currentPatient.insurance.deductibleRemaining} Ded. Remaining</span>
                </div>

                <div>
                  <span className="text-slate-400 font-semibold text-[10px] uppercase block">Visits Used / Auth</span>
                  <span className="font-mono font-bold text-teal-800">
                    {currentPatient.insurance.visitsUsed} / {currentPatient.insurance.visitsAuthorized} visits
                  </span>
                  <span className="text-slate-500 text-[11px] block">Auth: {currentPatient.insurance.preAuthNumber || 'Active'}</span>
                </div>
              </div>
            </div>

            {/* Active Problem List / Diagnoses */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Active Clinical Diagnoses (ICD-10-CM)
                </h3>
              </div>

              <div className="space-y-2">
                {currentPatient.diagnoses.map((diag) => (
                  <div
                    key={diag.code}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                        {diag.code}
                      </span>
                      <span className="font-semibold text-slate-800">{diag.description}</span>
                    </div>
                    {/* Zero-Pill unboxed metadata */}
                    <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                      <span>{diag.isPrimary ? 'Primary Diagnosis' : 'Secondary'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{diag.dateAdded}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Historical Encounters & SOAP Notes */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Clinical Encounter History & SOAP Notes ({patientSoapNotes.length})
                </h3>
                <button
                  onClick={() => onOpenOutcomeForPatient(currentPatient.id)}
                  className="text-xs text-teal-700 hover:underline font-semibold"
                >
                  View Outcome Metrics & ROM →
                </button>
              </div>

              {patientSoapNotes.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  <FileText className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                  <p className="font-semibold text-slate-600">No signed SOAP notes for this episode yet.</p>
                  <button
                    onClick={() => { setSelectedSoapToView(null); setIsSoapModalOpen(true); }}
                    className="mt-2 text-xs font-semibold text-teal-600 hover:text-teal-800"
                  >
                    + Create First SOAP Note
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {patientSoapNotes.map((note) => (
                    <div key={note.id} className="p-4 hover:bg-slate-50/70 transition-colors space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-900">{note.date}</span>
                          <span className="text-slate-400 font-mono">({note.time})</span>
                          <span className="text-slate-400">·</span>
                          <span className="font-semibold text-slate-700">{note.signedBy || 'Attending Clinician'}</span>
                        </div>
                        {note.signed ? (
                          <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                            <Lock className="w-3 h-3" /> Signed & Locked
                          </span>
                        ) : (
                          <span className="text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            Draft Note
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-700 space-y-1">
                        <p><span className="font-semibold text-slate-900">S:</span> {note.subjective.chiefComplaint} · VAS {note.subjective.vasScore}/10</p>
                        <p><span className="font-semibold text-slate-900">O:</span> {note.objective.palpationNotes}</p>
                        <p><span className="font-semibold text-slate-900">A:</span> {note.assessment.clinicalProgress} — {note.assessment.prognosis}</p>
                        <p><span className="font-semibold text-slate-900">P:</span> {note.plan.spinalAdjustments} | CPTs: {note.plan.cptCodes.join(', ')}</p>
                      </div>

                      <div className="flex justify-end pt-1">
                        <button
                          onClick={() => { setSelectedSoapToView(note); setIsSoapModalOpen(true); }}
                          className="text-xs text-teal-700 hover:text-teal-900 font-medium"
                        >
                          View Full Signed Note & Subluxation Chart →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* SOAP Modal */}
      {isSoapModalOpen && (
        <SoapNoteModal
          isOpen={isSoapModalOpen}
          onClose={() => { setIsSoapModalOpen(false); setSelectedSoapToView(null); }}
          onSave={onSaveSoapNote}
          patient={currentPatient}
          provider={primaryProvider}
          existingNote={selectedSoapToView || undefined}
        />
      )}
    </div>
  );
};
