import React, { useState, useEffect } from 'react';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  PhoneOff, 
  Share2, 
  Maximize2, 
  Play, 
  Pause, 
  RotateCcw, 
  Check, 
  AlertCircle, 
  User, 
  Sparkles, 
  FileText, 
  Activity, 
  ChevronRight,
  ShieldCheck,
  Volume2
} from 'lucide-react';
import { Patient, Provider, ExerciseItem, Appointment } from '../../types';
import { EXERCISE_LIBRARY } from '../../data/exerciseLibrary';

interface TelehealthModuleProps {
  patients: Patient[];
  providers: Provider[];
  appointments: Appointment[];
  activeAppointmentId?: string;
  onSaveSessionNotes?: (patientId: string, notes: string) => void;
  onCompleteSession?: (appointmentId: string) => void;
}

export const TelehealthModule: React.FC<TelehealthModuleProps> = ({
  patients,
  providers,
  appointments,
  activeAppointmentId,
  onSaveSessionNotes,
  onCompleteSession,
}) => {
  // Find appointment or default to a telehealth patient
  const [selectedPatientId, setSelectedPatientId] = useState<string>(
    patients[3]?.id || patients[0]?.id || ''
  );

  const selectedPatient = patients.find(p => p.id === selectedPatientId) || patients[0];
  const provider = providers[1] || providers[0];

  // Call states
  const [callActive, setCallActive] = useState<boolean>(true);
  const [callDuration, setCallDuration] = useState<number>(432); // e.g. 7m 12s
  const [micMuted, setMicMuted] = useState<boolean>(false);
  const [cameraOff, setCameraOff] = useState<boolean>(false);
  const [screenSharing, setScreenSharing] = useState<boolean>(false);
  const [postureGuideActive, setPostureGuideActive] = useState<boolean>(true);

  // Exercise runner states
  const [selectedExercise, setSelectedExercise] = useState<ExerciseItem>(EXERCISE_LIBRARY[0]);
  const [repCount, setRepCount] = useState<number>(4);
  const [targetReps, setTargetReps] = useState<number>(10);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [holdTimer, setHoldTimer] = useState<number>(selectedExercise.holdSeconds || 4);
  const [inCallNotes, setInCallNotes] = useState<string>(
    'Patient demonstrating improved thoracic rotation during side-lying open book. Mild compensatory hip rolling noted on rep 3; cueing engaged core and knees pinned.'
  );
  const [notesSaved, setNotesSaved] = useState<boolean>(false);

  // Call timer effect
  useEffect(() => {
    let interval: any = null;
    if (callActive) {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callActive]);

  // Hold timer countdown effect
  useEffect(() => {
    let timer: any = null;
    if (timerRunning && holdTimer > 0) {
      timer = setInterval(() => {
        setHoldTimer(prev => prev - 1);
      }, 1000);
    } else if (holdTimer === 0 && timerRunning) {
      setTimerRunning(false);
      setRepCount(prev => prev + 1);
      setHoldTimer(selectedExercise.holdSeconds);
    }
    return () => clearInterval(timer);
  }, [timerRunning, holdTimer, selectedExercise]);

  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  const handleSelectExercise = (ex: ExerciseItem) => {
    setSelectedExercise(ex);
    setRepCount(0);
    setTargetReps(ex.reps);
    setHoldTimer(ex.holdSeconds);
    setTimerRunning(false);
  };

  const handleSaveNotes = () => {
    if (onSaveSessionNotes && selectedPatient) {
      onSaveSessionNotes(selectedPatient.id, inCallNotes);
    }
    setNotesSaved(true);
    setTimeout(() => setNotesSaved(false), 3000);
  };

  const handleEndCall = () => {
    setCallActive(false);
    if (onCompleteSession && activeAppointmentId) {
      onCompleteSession(activeAppointmentId);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Patient / Room Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
            <Video className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-slate-900">
                Encrypted Virtual Rehab Suite
              </span>
              <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {callActive ? 'HIPAA WebRTC Encrypted (Connected)' : 'Call Ended'}
              </span>
            </div>
            {/* Zero-Pill unboxed metadata */}
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>Patient:</span>
              <select
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="font-bold text-slate-800 bg-transparent border-none focus:outline-none cursor-pointer"
              >
                {patients.map(p => (
                  <option key={p.id} value={p.id}>{p.lastName}, {p.firstName} ({p.mrn})</option>
                ))}
              </select>
              <span aria-hidden="true">·</span>
              <span>Attending: {provider.name}, {provider.credentials}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums font-semibold text-slate-700">
                Call: {formatDuration(callDuration)}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {callActive ? (
            <button
              onClick={handleEndCall}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors shadow-xs"
            >
              <PhoneOff className="w-3.5 h-3.5" /> End Virtual Visit
            </button>
          ) : (
            <button
              onClick={() => { setCallActive(true); setCallDuration(0); }}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors shadow-xs"
            >
              <Video className="w-3.5 h-3.5" /> Reconnect Session
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Video Feeds & Real-Time Rehab Coach */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (8 cols): Interactive Dual-Video Canvas */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Main Video Viewport (Patient & Guide) */}
          <div className="relative bg-slate-950 rounded-2xl overflow-hidden aspect-video shadow-lg border border-slate-800 flex items-center justify-center">
            
            {callActive ? (
              <div className="w-full h-full relative flex items-center justify-center bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900">
                
                {/* Simulated Patient Video Stream Canvas */}
                <div className="absolute inset-0 flex items-center justify-center p-8">
                  {/* Stylized Human Biomechanics Figure performing exercise */}
                  <svg viewBox="0 0 400 300" className="w-full h-full max-h-72 opacity-90">
                    <defs>
                      <linearGradient id="ptGlow" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#0d9488" />
                        <stop offset="100%" stopColor="#0284c7" />
                      </linearGradient>
                    </defs>

                    {/* Floor / Mat grid line */}
                    <line x1="40" y1="240" x2="360" y2="240" stroke="#334155" strokeWidth="2" strokeDasharray="4 4" />
                    
                    {/* Biomechanical Wireframe Skeleton */}
                    {/* Head */}
                    <circle cx="200" cy="70" r="18" fill="none" stroke="#38bdf8" strokeWidth="3" />
                    {/* Spine Column */}
                    <line x1="200" y1="88" x2="200" y2="160" stroke="#38bdf8" strokeWidth="4" />
                    {/* Shoulder girdle */}
                    <line x1="160" y1="105" x2="240" y2="105" stroke="#38bdf8" strokeWidth="3" />
                    {/* Left Arm */}
                    <line x1="160" y1="105" x2="135" y2="140" stroke="#38bdf8" strokeWidth="3" />
                    <line x1="135" y1="140" x2="115" y2="170" stroke="#38bdf8" strokeWidth="3" />
                    {/* Right Arm */}
                    <line x1="240" y1="105" x2="265" y2="140" stroke="#38bdf8" strokeWidth="3" />
                    <line x1="265" y1="140" x2="285" y2="170" stroke="#38bdf8" strokeWidth="3" />
                    {/* Pelvic girdle */}
                    <line x1="175" y1="160" x2="225" y2="160" stroke="#38bdf8" strokeWidth="3" />
                    {/* Left Leg */}
                    <line x1="180" y1="160" x2="170" y2="205" stroke="#38bdf8" strokeWidth="3" />
                    <line x1="170" y1="205" x2="165" y2="240" stroke="#38bdf8" strokeWidth="3" />
                    {/* Right Leg */}
                    <line x1="220" y1="160" x2="230" y2="205" stroke="#38bdf8" strokeWidth="3" />
                    <line x1="230" y1="205" x2="235" y2="240" stroke="#38bdf8" strokeWidth="3" />

                    {/* Joint Landmark tracking points */}
                    {postureGuideActive && (
                      <>
                        <circle cx="200" cy="70" r="4" fill="#34d399" />
                        <circle cx="160" cy="105" r="4" fill="#34d399" />
                        <circle cx="240" cy="105" r="4" fill="#34d399" />
                        <circle cx="200" cy="125" r="3" fill="#fbbf24" />
                        <circle cx="200" cy="160" r="4" fill="#34d399" />
                        <circle cx="170" cy="205" r="4" fill="#34d399" />
                        <circle cx="230" cy="205" r="4" fill="#34d399" />

                        {/* Posture alignment horizontal plumb line */}
                        <line x1="130" y1="105" x2="270" y2="105" stroke="#34d399" strokeWidth="1" strokeDasharray="3 3" opacity="0.6" />
                        <line x1="150" y1="160" x2="250" y2="160" stroke="#34d399" strokeWidth="1" strokeDasharray="3 3" opacity="0.6" />
                        
                        <text x="210" y="130" fill="#34d399" fontSize="10" fontFamily="monospace">Thoracic Alignment: 94%</text>
                      </>
                    )}
                  </svg>
                </div>

                {/* Patient Information Scrim Overlay */}
                <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs text-white flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-semibold">{selectedPatient?.firstName} {selectedPatient?.lastName}</span>
                  <span className="text-slate-400">·</span>
                  <span className="text-slate-300 font-mono text-[11px]">HD 1080p · 60fps</span>
                </div>

                {/* Posture Alignment Badge */}
                {postureGuideActive && (
                  <div className="absolute top-3 right-3 bg-teal-900/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-teal-500/40 text-[11px] text-teal-200 font-mono">
                    Biomechanics Mesh: Active
                  </div>
                )}

                {/* Clinician PiP (Picture-in-Picture) Camera Feed */}
                <div className="absolute bottom-4 right-4 w-36 sm:w-44 aspect-video bg-slate-800 rounded-xl overflow-hidden border-2 border-slate-700 shadow-xl flex items-center justify-center">
                  {!cameraOff ? (
                    <div className="w-full h-full bg-slate-800 flex flex-col items-center justify-center text-slate-200 p-2 text-center">
                      <div className="w-7 h-7 rounded-full bg-teal-600 text-white font-bold text-xs flex items-center justify-center mb-1">
                        {provider.avatarInitials}
                      </div>
                      <span className="text-[10px] font-semibold text-white truncate max-w-[120px]">
                        {provider.name}
                      </span>
                      <span className="text-[9px] text-slate-400">Clinician View</span>
                    </div>
                  ) : (
                    <div className="text-center text-slate-400">
                      <VideoOff className="w-5 h-5 mx-auto mb-1 text-slate-500" />
                      <span className="text-[10px]">Camera Paused</span>
                    </div>
                  )}
                  {micMuted && (
                    <div className="absolute bottom-1 left-1 bg-rose-600 text-white p-0.5 rounded">
                      <MicOff className="w-3 h-3" />
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center text-slate-400 p-6">
                <VideoOff className="w-10 h-10 mx-auto mb-2 text-slate-600" />
                <p className="text-sm font-semibold text-slate-300">Virtual Rehab Session Disconnected</p>
                <p className="text-xs text-slate-500 mt-1">Click "Reconnect Session" above to resume video feed</p>
              </div>
            )}
          </div>

          {/* Call Control Toolbar */}
          <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setMicMuted(!micMuted)}
                className={`p-2 rounded-lg border transition-colors ${
                  micMuted 
                    ? 'bg-rose-50 text-rose-700 border-rose-200' 
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
                title={micMuted ? 'Unmute Microphone' : 'Mute Microphone'}
              >
                {micMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setCameraOff(!cameraOff)}
                className={`p-2 rounded-lg border transition-colors ${
                  cameraOff 
                    ? 'bg-rose-50 text-rose-700 border-rose-200' 
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
                title={cameraOff ? 'Turn On Camera' : 'Turn Off Camera'}
              >
                {cameraOff ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setScreenSharing(!screenSharing)}
                className={`p-2 rounded-lg border transition-colors ${
                  screenSharing 
                    ? 'bg-teal-50 text-teal-700 border-teal-200' 
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
                title="Share Screen / Exercise Video"
              >
                <Share2 className="w-4 h-4" />
              </button>

              <button
                onClick={() => setPostureGuideActive(!postureGuideActive)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                  postureGuideActive
                    ? 'bg-teal-50 text-teal-800 border-teal-300'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Alignment Mesh {postureGuideActive ? 'ON' : 'OFF'}
              </button>
            </div>

            <div className="text-xs text-slate-500 font-mono tabular-nums">
              Session: {formatDuration(callDuration)}
            </div>
          </div>

          {/* In-Call Encounter Scratchpad */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Live Telehealth Visit Notes
              </h4>
              {notesSaved && (
                <span className="text-[11px] font-semibold text-emerald-700 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Appended to Chart
                </span>
              )}
            </div>
            <textarea
              rows={3}
              value={inCallNotes}
              onChange={(e) => setInCallNotes(e.target.value)}
              placeholder="Record real-time movement quality, compensations, patient-reported symptoms, and modifications..."
              className="w-full p-2.5 text-xs border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
            <div className="flex justify-end">
              <button
                onClick={handleSaveNotes}
                className="px-3 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors inline-flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5" /> Save to Patient Chart
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Guided Exercise Prescription & Interactive Rep Runner */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Active Exercise Coaching Card */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
            
            <div className="border-b border-slate-100 pb-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded">
                  {selectedExercise.region} · {selectedExercise.category}
                </span>
                <span className="text-xs font-mono text-slate-400">
                  Hold: {selectedExercise.holdSeconds}s
                </span>
              </div>
              <h3 className="text-sm font-bold text-slate-900 mt-1.5">
                {selectedExercise.name}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Target: {selectedExercise.targetMuscles}
              </p>
            </div>

            {/* Interactive Rep & Hold Timer Runner */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="grid grid-cols-2 gap-3 text-center">
                
                {/* Repetition Counter */}
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Reps Completed</span>
                  <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 my-0.5">
                    {repCount} <span className="text-xs text-slate-400 font-normal">/ {targetReps}</span>
                  </div>
                  <div className="flex justify-center gap-1 mt-1">
                    <button
                      onClick={() => setRepCount(Math.max(0, repCount - 1))}
                      className="px-2 py-0.5 text-xs bg-slate-100 hover:bg-slate-200 rounded text-slate-700 font-mono"
                    >
                      -1
                    </button>
                    <button
                      onClick={() => setRepCount(repCount + 1)}
                      className="px-2 py-0.5 text-xs bg-teal-600 hover:bg-teal-700 rounded text-white font-semibold"
                    >
                      +1 Rep
                    </button>
                  </div>
                </div>

                {/* Hold Countdown Timer */}
                <div className="bg-white p-2.5 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Hold Cadence</span>
                  <div className="text-2xl font-bold font-mono tabular-nums text-teal-800 my-0.5">
                    {holdTimer}s
                  </div>
                  <button
                    onClick={() => setTimerRunning(!timerRunning)}
                    className={`px-3 py-1 text-xs font-semibold rounded transition-colors inline-flex items-center gap-1 ${
                      timerRunning
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-teal-100 text-teal-900 hover:bg-teal-200'
                    }`}
                  >
                    {timerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 fill-current" />}
                    {timerRunning ? 'Pause' : 'Start Hold'}
                  </button>
                </div>
              </div>

              {/* Progress bar across set */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-500 font-mono mb-1">
                  <span>Set Progress</span>
                  <span>{Math.round((repCount / targetReps) * 100)}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-teal-600 h-full rounded-full transition-all"
                    style={{ width: `${Math.min(100, (repCount / targetReps) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Step-by-Step Instructions */}
            <div className="space-y-1.5 text-xs text-slate-700">
              <span className="font-bold text-slate-900 block text-[11px] uppercase">
                Clinician Verbal Coaching Cues:
              </span>
              <ul className="list-decimal list-inside space-y-1 text-slate-600">
                {selectedExercise.instructions.map((inst, i) => (
                  <li key={i}>{inst}</li>
                ))}
              </ul>
            </div>

            {/* Warning / Common Error */}
            <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Common Form Breakdown:</span> {selectedExercise.commonMistakes}
              </div>
            </div>
          </div>

          {/* Quick Exercise Library Selector */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Prescribed Home Exercise Library
            </h4>
            
            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {EXERCISE_LIBRARY.map((ex) => {
                const isSelected = selectedExercise.id === ex.id;
                return (
                  <div
                    key={ex.id}
                    onClick={() => handleSelectExercise(ex)}
                    className={`p-2.5 rounded-lg border text-xs cursor-pointer transition-colors flex items-center justify-between ${
                      isSelected
                        ? 'bg-teal-50/80 border-teal-500 text-teal-950 font-bold'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p>{ex.name}</p>
                      <p className="text-[10px] text-slate-500 font-normal">
                        {ex.region} · {ex.sets} sets x {ex.reps} reps
                      </p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
