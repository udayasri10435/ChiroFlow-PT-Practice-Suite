import React, { useState } from 'react';
import { X, CheckCircle, Award, AlertCircle, FileCheck } from 'lucide-react';
import { Patient, Provider, OutcomeMeasure, OutcomeQuestionAnswer } from '../../types';
import { QUESTIONNAIRE_TEMPLATES } from '../../data/outcomeQuestionnaires';

interface NewAssessmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (outcome: OutcomeMeasure) => void;
  patients: Patient[];
  providers: Provider[];
  initialPatientId?: string;
  initialType?: 'ODI' | 'NDI';
}

export const NewAssessmentModal: React.FC<NewAssessmentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  patients,
  providers,
  initialPatientId,
  initialType = 'ODI',
}) => {
  const [patientId, setPatientId] = useState(initialPatientId || patients[0]?.id || '');
  const [providerId, setProviderId] = useState(providers[0]?.id || '');
  const [type, setType] = useState<'ODI' | 'NDI'>(initialType);
  const [milestone, setMilestone] = useState<'Intake / Baseline' | '2-Week Progress' | '4-Week Progress' | '8-Week Discharge / Re-eval'>('4-Week Progress');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [clinicalNotes, setClinicalNotes] = useState('');

  const template = QUESTIONNAIRE_TEMPLATES[type];
  const selectedPatient = patients.find(p => p.id === patientId);

  // Initialize answers if empty
  React.useEffect(() => {
    if (template) {
      const initial: Record<string, number> = {};
      template.sections.forEach((sec, idx) => {
        // default to mild/moderate if not set
        initial[sec.id] = 1;
      });
      setAnswers(initial);
    }
  }, [type, template]);

  if (!isOpen || !template) return null;

  const scoreResult = template.calculateScore(answers);

  const handleSelectOption = (sectionId: string, score: number) => {
    setAnswers(prev => ({ ...prev, [sectionId]: score }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const formattedAnswers: OutcomeQuestionAnswer[] = template.sections.map(sec => {
      const selectedScore = answers[sec.id] ?? 0;
      const opt = sec.options.find(o => o.score === selectedScore);
      return {
        questionId: sec.id,
        sectionTitle: sec.title,
        questionText: sec.title,
        selectedScore,
        selectedText: opt?.text || '',
      };
    });

    const newOutcome: OutcomeMeasure = {
      id: `out-${Date.now()}`,
      patientId,
      providerId,
      date,
      type,
      title: template.title,
      rawScore: scoreResult.rawScore,
      maxScore: scoreResult.maxScore,
      percentageScore: scoreResult.percentage,
      severityLevel: scoreResult.severityLevel,
      interpretation: scoreResult.clinicalInterpretation,
      answers: formattedAnswers,
      clinicalSignificanceNotes: clinicalNotes || `Assessment administered at ${milestone}. Raw score: ${scoreResult.rawScore}/${scoreResult.maxScore} (${scoreResult.percentage}%).`,
      visitMilestone: milestone,
    };

    onSave(newOutcome);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-3xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-teal-100 text-teal-800 rounded">
                {type} Survey
              </span>
              <h2 className="text-sm font-bold text-slate-900">{template.title}</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">{template.subtitle}</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Configuration Row */}
        <div className="px-6 py-3 bg-slate-100/70 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3 shrink-0">
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Patient</label>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
            >
              {patients.map(p => (
                <option key={p.id} value={p.id}>{p.lastName}, {p.firstName} ({p.mrn})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Survey Battery</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as any)}
              className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
            >
              <option value="ODI">Oswestry Low Back (ODI)</option>
              <option value="NDI">Neck Disability Index (NDI)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Episode Milestone</label>
            <select
              value={milestone}
              onChange={(e) => setMilestone(e.target.value as any)}
              className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
            >
              <option value="Intake / Baseline">Intake / Baseline</option>
              <option value="2-Week Progress">2-Week Progress</option>
              <option value="4-Week Progress">4-Week Progress</option>
              <option value="8-Week Discharge / Re-eval">8-Week Discharge / Re-eval</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-0.5">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full px-2 py-1 text-xs font-mono tabular-nums border border-slate-300 rounded bg-white"
            />
          </div>
        </div>

        {/* Live Calculation Banner */}
        <div className="px-6 py-2.5 bg-teal-50/60 border-b border-teal-100 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-teal-700" />
            <span className="font-semibold text-teal-900">Current Score:</span>
            <span className="font-mono font-bold text-teal-800 text-sm">
              {scoreResult.percentage}% ({scoreResult.rawScore} / {scoreResult.maxScore} pts)
            </span>
            <span className="text-slate-500">·</span>
            <span className="font-medium text-slate-700">{scoreResult.severityLevel}</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono">
            MCID Target: {template.mcidThreshold} pts
          </div>
        </div>

        {/* Questions Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {template.sections.map((section, secIdx) => {
            const currentScore = answers[section.id] ?? 0;
            return (
              <div key={section.id} className="border border-slate-200 rounded-lg p-4 bg-white shadow-xs">
                <h3 className="text-xs font-bold text-slate-900 mb-2">
                  {section.title}
                </h3>
                <div className="space-y-1.5">
                  {section.options.map((opt) => {
                    const isSelected = currentScore === opt.score;
                    return (
                      <label
                        key={opt.score}
                        onClick={() => handleSelectOption(section.id, opt.score)}
                        className={`flex items-start gap-2.5 p-2 rounded-md border text-xs cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-teal-50/80 border-teal-400 text-teal-950 font-medium'
                            : 'bg-white border-slate-100 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="radio"
                          name={section.id}
                          checked={isSelected}
                          onChange={() => handleSelectOption(section.id, opt.score)}
                          className="mt-0.5 text-teal-600 focus:ring-teal-500"
                        />
                        <span className="font-mono text-slate-400 font-semibold w-4 shrink-0">
                          {opt.score}.
                        </span>
                        <span>{opt.text}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            );
          })}

          {/* Clinician Notes */}
          <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
            <label className="block text-xs font-semibold text-slate-800 mb-1">
              Clinician Assessment & Functional Significance Notes
            </label>
            <textarea
              rows={2}
              value={clinicalNotes}
              onChange={(e) => setClinicalNotes(e.target.value)}
              placeholder="e.g. Patient demonstrates 18% improvement surpassing MCID. Recommend continuing chiropractic manipulation and progression to resistance exercises."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-200 rounded-lg"
          >
            Cancel
          </button>
          
          <button
            type="button"
            onClick={handleSubmit}
            className="px-5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs inline-flex items-center gap-1.5"
          >
            <FileCheck className="w-3.5 h-3.5" /> Save Outcome Assessment
          </button>
        </div>
      </div>
    </div>
  );
};
