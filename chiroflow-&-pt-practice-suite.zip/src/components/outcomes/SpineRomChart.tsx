import React, { useState } from 'react';
import { Activity, ShieldCheck, AlertCircle, Save } from 'lucide-react';
import { RomMeasurement } from '../../types';

interface SpineRomChartProps {
  initialVas?: number;
  onUpdateVas?: (vas: number) => void;
}

export const SpineRomChart: React.FC<SpineRomChartProps> = ({
  initialVas = 3,
  onUpdateVas,
}) => {
  const [vas, setVas] = useState(initialVas);
  const [roms, setRoms] = useState<RomMeasurement[]>([
    { region: 'Cervical', movement: 'Flexion', measuredDegrees: 42, normalDegrees: 50, painOnMotion: false },
    { region: 'Cervical', movement: 'Extension', measuredDegrees: 48, normalDegrees: 60, painOnMotion: true },
    { region: 'Cervical', movement: 'Right Rotation', measuredDegrees: 65, normalDegrees: 80, painOnMotion: false },
    { region: 'Cervical', movement: 'Left Rotation', measuredDegrees: 70, normalDegrees: 80, painOnMotion: false },
    { region: 'Lumbar', movement: 'Flexion', measuredDegrees: 62, normalDegrees: 80, painOnMotion: false },
    { region: 'Lumbar', movement: 'Extension', measuredDegrees: 18, normalDegrees: 25, painOnMotion: true },
    { region: 'Lumbar', movement: 'Right Lateral Flexion', measuredDegrees: 22, normalDegrees: 25, painOnMotion: false },
  ]);

  const [orthoTests, setOrthoTests] = useState([
    { name: 'Straight Leg Raise (SLR) - Left', result: 'Negative (75°)', status: 'normal' },
    { name: 'Straight Leg Raise (SLR) - Right', result: 'Negative (80°)', status: 'normal' },
    { name: 'Slump Test (Neural Tension)', result: 'Negative', status: 'normal' },
    { name: "Kemp's Test (Lumbar Facet)", result: 'Mild localized ache on right', status: 'mild' },
    { name: "Spurling's Test (Cervical Radiculopathy)", result: 'Negative', status: 'normal' },
    { name: 'Deep Tendon Reflexes (Patellar L4 / Achilles S1)', result: '2+ Bilaterally Symmetrical', status: 'normal' },
  ]);

  const handleVasChange = (newVal: number) => {
    setVas(newVal);
    if (onUpdateVas) onUpdateVas(newVal);
  };

  const handleRomChange = (index: number, newDegrees: number) => {
    setRoms(prev => {
      const copy = [...prev];
      copy[index] = { ...copy[index], measuredDegrees: newDegrees };
      return copy;
    });
  };

  const getVasDescriptor = (v: number) => {
    if (v === 0) return '0 / 10 · Complete Absence of Pain';
    if (v <= 2) return `${v} / 10 · Mild · Noticeable, does not impede daily activity`;
    if (v <= 4) return `${v} / 10 · Moderate · Interferes with concentration and lifting`;
    if (v <= 6) return `${v} / 10 · Moderately Severe · Limits routine work and driving`;
    if (v <= 8) return `${v} / 10 · Severe · Disabling, prevents self-care`;
    return `${v} / 10 · Extreme · Unbearable pain requiring acute intervention`;
  };

  return (
    <div className="space-y-5">
      
      {/* Interactive Visual Analog Pain Scale (VAS) */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Visual Analog Scale (VAS / NPRS) Pain Metric
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Current functional pain self-report</p>
          </div>
          <div className="text-right">
            <span className="font-mono font-bold text-lg tabular-nums text-slate-900">
              {vas}
            </span>
            <span className="text-xs text-slate-400 font-mono"> / 10</span>
          </div>
        </div>

        {/* Range Slider */}
        <div className="space-y-2">
          <input
            type="range"
            min="0"
            max="10"
            step="1"
            value={vas}
            onChange={(e) => handleVasChange(Number(e.target.value))}
            className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-600"
          />

          <div className="flex justify-between text-[10px] text-slate-400 font-mono">
            <span>0 (No Pain)</span>
            <span>2</span>
            <span>4</span>
            <span>6</span>
            <span>8</span>
            <span>10 (Worst Pain)</span>
          </div>
        </div>

        <div className="mt-3 p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700">
          Clinical Interpretation: <span className="font-semibold text-slate-900">{getVasDescriptor(vas)}</span>
        </div>
      </div>

      {/* Range of Motion (ROM) Table with Percentage Norms */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Spinal Range of Motion (Goniometric Inclinometer)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Measured active excursion compared to AMA Guides normative data</p>
          </div>
        </div>

        <div className="space-y-3">
          {roms.map((rom, idx) => {
            const pctOfNormal = Math.min(100, Math.round((rom.measuredDegrees / rom.normalDegrees) * 100));
            const isRestricted = pctOfNormal < 85;

            return (
              <div key={rom.movement} className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{rom.region} {rom.movement}</span>
                    {rom.painOnMotion && (
                      <span className="text-[10px] text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                        Pain at End-Range
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <span className="text-slate-500">Measured:</span>
                      <input
                        type="number"
                        min="0"
                        max="120"
                        value={rom.measuredDegrees}
                        onChange={(e) => handleRomChange(idx, Number(e.target.value))}
                        className="w-14 text-center font-mono font-bold text-xs bg-white border border-slate-300 rounded px-1 py-0.5"
                      />
                      <span className="font-mono text-slate-500">°</span>
                    </div>
                    <span className="text-slate-400 font-mono text-[11px]">
                      (Normal: {rom.normalDegrees}°)
                    </span>
                  </div>
                </div>

                {/* Progress Bar of Excursion */}
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      pctOfNormal >= 90
                        ? 'bg-emerald-500'
                        : pctOfNormal >= 75
                        ? 'bg-amber-500'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${pctOfNormal}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
                  <span>{pctOfNormal}% of normal physiological excursion</span>
                  <span>{isRestricted ? 'Restricted Motion' : 'Functional Range'}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Orthopedic & Neurological Provocation Tests */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-3">
          Orthopedic & Dural Tension Tests
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {orthoTests.map((test, i) => (
            <div key={i} className="p-2.5 border border-slate-200 rounded-lg bg-slate-50 flex items-start justify-between text-xs">
              <div>
                <p className="font-semibold text-slate-900">{test.name}</p>
                <p className="text-slate-600 mt-0.5 text-[11px]">{test.result}</p>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-semibold shrink-0 ${
                test.status === 'normal' 
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                  : 'bg-amber-50 text-amber-800 border border-amber-200'
              }`}>
                {test.status === 'normal' ? 'Normal' : 'Positive'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
