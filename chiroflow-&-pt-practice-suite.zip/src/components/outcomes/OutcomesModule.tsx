import React, { useState } from 'react';
import { 
  Award, 
  TrendingDown, 
  Activity, 
  Plus, 
  User, 
  FileText, 
  Printer, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  BarChart3
} from 'lucide-react';
import { OutcomeMeasure, Patient, Provider } from '../../types';
import { NewAssessmentModal } from './NewAssessmentModal';
import { SpineRomChart } from './SpineRomChart';

interface OutcomesModuleProps {
  outcomes: OutcomeMeasure[];
  patients: Patient[];
  providers: Provider[];
  onSaveOutcome: (outcome: OutcomeMeasure) => void;
  selectedPatientId?: string;
  onSelectPatientId?: (id: string) => void;
}

export const OutcomesModule: React.FC<OutcomesModuleProps> = ({
  outcomes,
  patients,
  providers,
  onSaveOutcome,
  selectedPatientId,
  onSelectPatientId,
}) => {
  const [activePatientId, setActivePatientId] = useState<string>(
    selectedPatientId || patients[0]?.id || ''
  );
  const [activeTab, setActiveTab] = useState<'surveys' | 'rom_vas' | 'report'>('surveys');
  const [isNewAssessmentOpen, setIsNewAssessmentOpen] = useState(false);
  const [assessmentType, setAssessmentType] = useState<'ODI' | 'NDI'>('ODI');

  const currentPatient = patients.find(p => p.id === activePatientId) || patients[0];
  const patientOutcomes = outcomes
    .filter(o => o.patientId === currentPatient?.id)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Determine recovery delta
  const initialAssessment = patientOutcomes[0];
  const latestAssessment = patientOutcomes[patientOutcomes.length - 1];
  const deltaPoints = initialAssessment && latestAssessment && initialAssessment.id !== latestAssessment.id
    ? initialAssessment.percentageScore - latestAssessment.percentageScore
    : 0;

  const handlePatientChange = (id: string) => {
    setActivePatientId(id);
    if (onSelectPatientId) onSelectPatientId(id);
  };

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      
      {/* Top Patient Selector & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-sm shrink-0">
            {currentPatient?.firstName[0]}{currentPatient?.lastName[0]}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <select
                value={activePatientId}
                onChange={(e) => handlePatientChange(e.target.value)}
                className="text-sm font-bold text-slate-900 bg-transparent border-none focus:outline-none cursor-pointer p-0"
              >
                {patients.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.lastName}, {p.firstName} · {p.mrn}
                  </option>
                ))}
              </select>
            </div>
            {/* Zero-Pill unboxed metadata */}
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>{currentPatient?.insurance.payerName}</span>
              <span aria-hidden="true">·</span>
              <span>Episode Start: {currentPatient?.episodeStart}</span>
              <span aria-hidden="true">·</span>
              <span>{currentPatient?.carePlanPhase}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Segmented Subtabs */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg border border-slate-200">
            <button
              onClick={() => setActiveTab('surveys')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'surveys'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Outcome Battery (ODI/NDI)
            </button>
            <button
              onClick={() => setActiveTab('rom_vas')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'rom_vas'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Spine ROM & VAS Pain
            </button>
            <button
              onClick={() => setActiveTab('report')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'report'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Re-Authorization Report
            </button>
          </div>

          <button
            onClick={() => setIsNewAssessmentOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors shadow-xs shrink-0"
          >
            <Plus className="w-3.5 h-3.5" /> Administer Survey
          </button>
        </div>
      </div>

      {/* Tab 1: Functional Surveys (ODI / NDI) */}
      {activeTab === 'surveys' && (
        <div className="space-y-6">
          
          {/* Longitudinal Progress Chart Bar */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Longitudinal Functional Recovery Timeline
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Comparison across clinical milestones against the Minimal Clinically Important Difference (MCID)
                </p>
              </div>

              {deltaPoints > 0 && (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                  <TrendingDown className="w-4 h-4 text-emerald-600" />
                  <span>{deltaPoints}% Total Disability Reduction</span>
                  <span className="text-[11px] font-normal text-emerald-700">(Exceeds 10% MCID Threshold)</span>
                </div>
              )}
            </div>

            {/* Visual Step-by-Step Trajectory */}
            {patientOutcomes.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No standardized outcome surveys recorded yet for this patient.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                {patientOutcomes.map((item, idx) => {
                  const isImprovement = idx > 0 && item.percentageScore < patientOutcomes[0].percentageScore;
                  const deltaFromStart = idx > 0 ? patientOutcomes[0].percentageScore - item.percentageScore : 0;

                  return (
                    <div
                      key={item.id}
                      className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="font-semibold text-slate-900">{item.visitMilestone}</span>
                          <span className="font-mono text-slate-500 tabular-nums">{item.date}</span>
                        </div>
                        <p className="text-[11px] text-slate-500">{item.title}</p>

                        <div className="my-3 flex items-baseline gap-2">
                          <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
                            {item.percentageScore}%
                          </span>
                          <span className="text-xs text-slate-400 font-mono">
                            ({item.rawScore} / {item.maxScore} pts)
                          </span>
                        </div>

                        <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-2">
                          <div
                            className={`h-full rounded-full transition-all ${
                              item.percentageScore <= 20
                                ? 'bg-emerald-500'
                                : item.percentageScore <= 40
                                ? 'bg-teal-500'
                                : item.percentageScore <= 60
                                ? 'bg-amber-500'
                                : 'bg-rose-500'
                            }`}
                            style={{ width: `${item.percentageScore}%` }}
                          />
                        </div>

                        <p className="text-xs font-semibold text-slate-700">{item.severityLevel}</p>
                        <p className="text-[11px] text-slate-600 mt-1 line-clamp-2 italic">
                          "{item.clinicalSignificanceNotes}"
                        </p>
                      </div>

                      {idx > 0 && (
                        <div className="mt-3 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px]">
                          <span className="text-slate-500">Progress vs Baseline:</span>
                          <span className="font-mono font-bold text-emerald-700">-{deltaFromStart}% Disability</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Historical Assessment Records List */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Completed Standardized Questionnaires ({patientOutcomes.length})
              </h3>
            </div>

            <div className="divide-y divide-slate-100">
              {patientOutcomes.map((item) => (
                <div key={item.id} className="p-4 hover:bg-slate-50/60 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">
                        {item.title} · <span className="font-normal text-slate-600">{item.visitMilestone}</span>
                      </h4>
                      <p className="text-[11px] text-slate-500 font-mono tabular-nums">
                        Administered: {item.date} · Score: {item.rawScore}/{item.maxScore} ({item.percentageScore}%)
                      </p>
                    </div>
                    <span className="text-xs font-semibold text-slate-800 bg-slate-100 px-2.5 py-1 rounded border border-slate-200">
                      {item.severityLevel}
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-100 mt-1">
                    <span className="font-semibold">Clinical Interpretation:</span> {item.interpretation}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Spine ROM & Pain Scale */}
      {activeTab === 'rom_vas' && (
        <SpineRomChart
          initialVas={currentPatient?.currentPainVas || 3}
          onUpdateVas={(v) => {
            if (currentPatient) currentPatient.currentPainVas = v;
          }}
        />
      )}

      {/* Tab 3: Re-Authorization Clinical Progress Report */}
      {activeTab === 'report' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Functional Outcomes Re-Authorization Summary
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Formatted for Insurance Medical Review (Aetna, Blue Shield, UHC, Medicare Part B)
              </p>
            </div>
            <button
              onClick={handlePrintReport}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <Printer className="w-3.5 h-3.5" /> Print / Export PDF
            </button>
          </div>

          {/* Patient Details & Payer Info */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-3.5 bg-slate-50 rounded-lg text-xs">
            <div>
              <span className="text-slate-400 font-semibold text-[10px] uppercase block">Patient Name</span>
              <span className="font-bold text-slate-900">{currentPatient?.lastName}, {currentPatient?.firstName}</span>
            </div>
            <div>
              <span className="text-slate-400 font-semibold text-[10px] uppercase block">MRN / DOB</span>
              <span className="font-mono text-slate-900">{currentPatient?.mrn} · {currentPatient?.dob}</span>
            </div>
            <div>
              <span className="text-slate-400 font-semibold text-[10px] uppercase block">Primary Insurer</span>
              <span className="text-slate-900">{currentPatient?.insurance.payerName}</span>
            </div>
            <div>
              <span className="text-slate-400 font-semibold text-[10px] uppercase block">Pre-Auth / Policy</span>
              <span className="font-mono text-slate-900">{currentPatient?.insurance.preAuthNumber || currentPatient?.insurance.policyId}</span>
            </div>
          </div>

          {/* Primary Diagnoses & Episode Care */}
          <div className="text-xs space-y-2">
            <h4 className="font-bold text-slate-900 uppercase text-[11px]">Primary Diagnoses Under Active Care:</h4>
            <div className="space-y-1">
              {currentPatient?.diagnoses.map(d => (
                <div key={d.code} className="flex items-center gap-2">
                  <span className="font-mono font-bold text-slate-900 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                    {d.code}
                  </span>
                  <span className="text-slate-700">{d.description}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Objective Outcome Measures Comparison Table */}
          <div>
            <h4 className="font-bold text-slate-900 uppercase text-[11px] mb-2">
              Standardized Functional Measure Trajectory (MCID Demonstration):
            </h4>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Milestone Date</th>
                    <th className="py-2.5 px-3">Outcome Instrument</th>
                    <th className="py-2.5 px-3 text-center">Raw Score</th>
                    <th className="py-2.5 px-3 text-center">% Disability</th>
                    <th className="py-2.5 px-3">Functional Severity</th>
                    <th className="py-2.5 px-3 text-right">MCID Met?</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {patientOutcomes.map((o, idx) => (
                    <tr key={o.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{o.date} ({o.visitMilestone})</td>
                      <td className="py-2.5 px-3 font-sans text-xs">{o.title}</td>
                      <td className="py-2.5 px-3 text-center">{o.rawScore} / {o.maxScore}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-slate-900">{o.percentageScore}%</td>
                      <td className="py-2.5 px-3 font-sans text-xs">{o.severityLevel}</td>
                      <td className="py-2.5 px-3 text-right font-sans text-xs font-bold text-emerald-700">
                        {idx > 0 && o.percentageScore < patientOutcomes[0].percentageScore ? 'YES (Clinically Significant)' : 'Baseline'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Medical Necessity Statement */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-2">
            <h4 className="font-bold text-slate-900">Clinician Attestation of Continued Medical Necessity:</h4>
            <p className="text-slate-700 leading-relaxed">
              Patient has demonstrated tangible functional progress ({deltaPoints}% reduction in ODI disability) under conservative chiropractic manipulation and supervised active physical therapy. To consolidate stabilization of spinal motor units, prevent acute regression, and achieve full independence in home exercise, an additional 12 visits of CMT (98941) and Therapeutic Exercise (97110) are medically necessary.
            </p>
            <div className="pt-2 flex justify-between items-center text-slate-500 font-mono text-[11px]">
              <span>Attending: Dr. Marcus Vance, DC (NPI: 1487295103)</span>
              <span>Signature: Dr. Marcus Vance, DC [Electronically Authenticated]</span>
            </div>
          </div>
        </div>
      )}

      {/* New Assessment Modal */}
      {isNewAssessmentOpen && (
        <NewAssessmentModal
          isOpen={isNewAssessmentOpen}
          onClose={() => setIsNewAssessmentOpen(false)}
          onSave={onSaveOutcome}
          patients={patients}
          providers={providers}
          initialPatientId={activePatientId}
          initialType={assessmentType}
        />
      )}
    </div>
  );
};
