import React, { useState } from 'react';
import { X, Calendar, Clock, User, Stethoscope, MapPin, DollarSign, FileText } from 'lucide-react';
import { Patient, Provider, Appointment, AppointmentType } from '../../types';

interface NewAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (appointment: Appointment) => void;
  patients: Patient[];
  providers: Provider[];
  initialDate?: string;
  initialTime?: string;
  initialProviderId?: string;
}

export const NewAppointmentModal: React.FC<NewAppointmentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  patients,
  providers,
  initialDate = '2026-09-29',
  initialTime = '10:00',
  initialProviderId,
}) => {
  const [patientId, setPatientId] = useState(patients[0]?.id || '');
  const [providerId, setProviderId] = useState(initialProviderId || providers[0]?.id || '');
  const [date, setDate] = useState(initialDate);
  const [time, setTime] = useState(initialTime);
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [type, setType] = useState<AppointmentType>('chiro_adjust');
  const [room, setRoom] = useState('Adjustment Bay 1');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [copayAmount, setCopayAmount] = useState(25);
  const [copayCollected, setCopayCollected] = useState(false);
  const [notes, setNotes] = useState('');

  // Auto-set copay when patient changes
  React.useEffect(() => {
    const selPat = patients.find(p => p.id === patientId);
    if (selPat) {
      setCopayAmount(selPat.insurance.copayAmount);
      if (!chiefComplaint && selPat.diagnoses[0]) {
        setChiefComplaint(`Care plan visit for ${selPat.diagnoses[0].description}`);
      }
    }
  }, [patientId, patients]);

  // Adjust default room based on provider / appointment type
  React.useEffect(() => {
    if (type === 'telehealth') {
      setRoom('Telehealth Room');
    } else if (type === 'pt_rehab') {
      setRoom('PT Gym & Turf');
    } else if (type === 'decompression') {
      setRoom('Traction Suite');
    } else if (type === 'dry_needling') {
      setRoom('Private Treatment 2');
    } else {
      const prov = providers.find(p => p.id === providerId);
      if (prov) setRoom(prov.defaultRoom);
    }
  }, [type, providerId, providers]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientId || !providerId) return;

    const newApt: Appointment = {
      id: `apt-${Date.now()}`,
      patientId,
      providerId,
      date,
      time,
      durationMinutes,
      type,
      room,
      status: 'scheduled',
      chiefComplaint: chiefComplaint || 'Routine evaluation and treatment',
      copayCollected,
      copayAmount,
      notes,
    };

    onSave(newApt);
    onClose();
  };

  const selectedPatient = patients.find(p => p.id === patientId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-xl rounded-xl shadow-xl border border-slate-200 overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Schedule New Appointment</h2>
            <p className="text-xs text-slate-500 mt-0.5">Book visit, assign practitioner, and allocate treatment bay</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          
          {/* Patient Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Select Patient
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500 focus:border-teal-500"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.lastName}, {p.firstName} · {p.mrn} · {p.insurance.payerName}
                  </option>
                ))}
              </select>
            </div>
            {selectedPatient && (
              <div className="mt-1 text-xs text-slate-500 flex items-center gap-2">
                <span>DOB: {selectedPatient.dob}</span>
                <span aria-hidden="true">·</span>
                <span>Copay: ${selectedPatient.insurance.copayAmount}</span>
                <span aria-hidden="true">·</span>
                <span>Phase: {selectedPatient.carePlanPhase}</span>
              </div>
            )}
          </div>

          {/* Practitioner & Modality Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Practitioner
              </label>
              <div className="relative">
                <Stethoscope className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <select
                  value={providerId}
                  onChange={(e) => setProviderId(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  {providers.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}, {p.credentials}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Visit Modality / Type
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as AppointmentType)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
              >
                <option value="chiro_adjust">Chiropractic Adjustment & CMT</option>
                <option value="pt_rehab">PT Manual & Therapeutic Exercise</option>
                <option value="initial_eval">Comprehensive Initial Evaluation</option>
                <option value="decompression">Spinal Decompression Traction</option>
                <option value="dry_needling">Dry Needling / Trigger Point</option>
                <option value="re_exam">Re-Exam & Functional Outcomes</option>
                <option value="telehealth">Telehealth Virtual Rehab</option>
              </select>
            </div>
          </div>

          {/* Date, Time, Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Date
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full pl-9 pr-2 py-2 text-xs font-mono tabular-nums border border-slate-300 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Time Slot
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  required
                  className="w-full pl-9 pr-2 py-2 text-xs font-mono tabular-nums border border-slate-300 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Duration
              </label>
              <select
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
              >
                <option value={15}>15 minutes (Quick CMT)</option>
                <option value={30}>30 minutes (Standard)</option>
                <option value={45}>45 minutes (PT Rehab)</option>
                <option value={60}>60 minutes (Comprehensive)</option>
              </select>
            </div>
          </div>

          {/* Room Allocation & Copay */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Treatment Room / Bay
              </label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                <select
                  value={room}
                  onChange={(e) => setRoom(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  <option value="Adjustment Bay 1">Adjustment Bay 1 (Zenith Table)</option>
                  <option value="Adjustment Bay 2">Adjustment Bay 2 (Thompson Drop)</option>
                  <option value="PT Gym & Turf">PT Gym & Functional Turf</option>
                  <option value="Traction Suite">Traction Suite (Chattanooga Decomp)</option>
                  <option value="Private Treatment 2">Private Treatment Rm 2</option>
                  <option value="Telehealth Room">Telehealth Virtual Suite</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Patient Copay ($)
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <DollarSign className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
                  <input
                    type="number"
                    min="0"
                    step="5"
                    value={copayAmount}
                    onChange={(e) => setCopayAmount(Number(e.target.value))}
                    className="w-full pl-9 pr-3 py-2 text-xs font-mono tabular-nums border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>
                <label className="flex items-center gap-1.5 text-xs text-slate-600 shrink-0 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={copayCollected}
                    onChange={(e) => setCopayCollected(e.target.checked)}
                    className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                  />
                  <span>Collected</span>
                </label>
              </div>
            </div>
          </div>

          {/* Chief Complaint / Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Chief Complaint / Clinical Purpose
            </label>
            <input
              type="text"
              value={chiefComplaint}
              onChange={(e) => setChiefComplaint(e.target.value)}
              placeholder="e.g. Lumbar spine subluxation check & core stabilization"
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>

          {/* Special Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Internal Clinical Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Pre-visit notes, contraindications, or imaging alerts..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500 resize-none"
            />
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-medium text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors shadow-xs"
            >
              Confirm Appointment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
