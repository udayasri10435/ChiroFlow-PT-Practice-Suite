import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  Video, 
  FileText, 
  Plus, 
  DollarSign, 
  Filter
} from 'lucide-react';
import { Appointment, Patient, Provider, AppointmentStatus } from '../../types';

interface ScheduleModuleProps {
  appointments: Appointment[];
  patients: Patient[];
  providers: Provider[];
  selectedDate: string;
  onDateChange: (date: string) => void;
  onUpdateStatus: (aptId: string, status: AppointmentStatus) => void;
  onNewAppointmentClick: (initialTime?: string, providerId?: string) => void;
  onOpenSoapNote: (patientId: string, appointmentId: string) => void;
  onStartTelehealth: (appointmentId: string) => void;
  onOpenBillingForApt: (appointment: Appointment) => void;
  selectedProviderFilter: string;
  onProviderFilterChange: (id: string) => void;
}

export const ScheduleModule: React.FC<ScheduleModuleProps> = ({
  appointments,
  patients,
  providers,
  selectedDate,
  onDateChange,
  onUpdateStatus,
  onNewAppointmentClick,
  onOpenSoapNote,
  onStartTelehealth,
  onOpenBillingForApt,
  selectedProviderFilter,
  onProviderFilterChange,
}) => {
  const [viewMode, setViewMode] = useState<'practitioner_columns' | 'room_columns' | 'list'>('practitioner_columns');
  const [modalityFilter, setModalityFilter] = useState<string>('all');

  // Filter appointments for selected date
  const dayAppointments = appointments.filter((apt) => apt.date === selectedDate);

  // Filter by provider
  const filteredAppointments = dayAppointments.filter((apt) => {
    if (selectedProviderFilter !== 'all' && apt.providerId !== selectedProviderFilter) return false;
    if (modalityFilter !== 'all' && apt.type !== modalityFilter) return false;
    return true;
  });

  // Calculate day metrics
  const totalCount = dayAppointments.length;
  const arrivedCount = dayAppointments.filter(a => a.status === 'arrived').length;
  const inSessionCount = dayAppointments.filter(a => a.status === 'in_session').length;
  const completedCount = dayAppointments.filter(a => a.status === 'completed').length;
  const copaysCollectedTotal = dayAppointments
    .filter(a => a.copayCollected)
    .reduce((sum, a) => sum + (a.copayAmount || 0), 0);

  // Navigation handlers
  const handlePrevDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    onDateChange(d.toISOString().split('T')[0]);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    onDateChange(d.toISOString().split('T')[0]);
  };

  const handleToday = () => {
    onDateChange('2026-09-29');
  };

  // Rooms list
  const rooms = [
    'Adjustment Bay 1',
    'Adjustment Bay 2',
    'PT Gym & Turf',
    'Traction Suite',
    'Private Treatment 2',
    'Telehealth Room',
  ];

  const getModalityLabel = (type: string) => {
    switch (type) {
      case 'chiro_adjust': return 'Chiro CMT Adjustment';
      case 'pt_rehab': return 'PT Therapeutic Exercise';
      case 'initial_eval': return 'Initial Exam & Eval';
      case 'decompression': return 'Spinal Decompression';
      case 'dry_needling': return 'Dry Needling';
      case 're_exam': return 'Re-Exam & Outcome Review';
      case 'telehealth': return 'Telehealth Rehab';
      default: return type;
    }
  };

  const getStatusColor = (status: AppointmentStatus) => {
    switch (status) {
      case 'arrived': return 'border-l-4 border-amber-500 bg-amber-50/40 text-amber-900';
      case 'in_session': return 'border-l-4 border-teal-500 bg-teal-50/50 text-teal-900';
      case 'completed': return 'border-l-4 border-slate-300 bg-slate-50 text-slate-600 opacity-80';
      case 'cancelled': return 'border-l-4 border-rose-400 bg-rose-50/40 text-rose-800 line-through';
      case 'no_show': return 'border-l-4 border-red-500 bg-red-50 text-red-800';
      default: return 'border-l-4 border-sky-400 bg-white text-slate-800';
    }
  };

  return (
    <div className="space-y-5">
      
      {/* Top Controls & Metrics Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        
        {/* Date Navigator */}
        <div className="flex items-center gap-2">
          <button
            onClick={handlePrevDay}
            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            title="Previous Day"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          
          <button
            onClick={handleToday}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Today
          </button>

          <button
            onClick={handleNextDay}
            className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            title="Next Day"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div className="ml-2">
            <span className="text-sm font-semibold text-slate-900">
              {new Date(selectedDate + 'T00:00:00').toLocaleDateString('en-US', {
                weekday: 'long',
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              })}
            </span>
            <span className="text-xs text-slate-500 ml-2 font-mono tabular-nums">
              ({dayAppointments.length} scheduled)
            </span>
          </div>
        </div>

        {/* View Mode & Modality Segmented Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Segmented View Mode */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200">
            <button
              onClick={() => setViewMode('practitioner_columns')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                viewMode === 'practitioner_columns'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              By Practitioner
            </button>
            <button
              onClick={() => setViewMode('room_columns')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                viewMode === 'room_columns'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              By Room / Bay
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                viewMode === 'list'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Day List
            </button>
          </div>

          {/* Modality Filter Dropdown */}
          <select
            value={modalityFilter}
            onChange={(e) => setModalityFilter(e.target.value)}
            className="px-2.5 py-1 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none"
          >
            <option value="all">All Modalities</option>
            <option value="chiro_adjust">Chiro CMT</option>
            <option value="pt_rehab">PT Rehab</option>
            <option value="decompression">Decompression</option>
            <option value="dry_needling">Dry Needling</option>
            <option value="telehealth">Telehealth</option>
            <option value="re_exam">Re-Exams</option>
          </select>
        </div>
      </div>

      {/* Quantitative Clinical Flow Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white p-3 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500">Day Total</p>
          <p className="text-lg font-bold font-mono tabular-nums text-slate-900">{totalCount}</p>
          <p className="text-xs text-slate-400 mt-0.5">Visits scheduled</p>
        </div>
        
        <div className="bg-white p-3 rounded-lg border border-slate-200">
          <p className="text-xs text-amber-700 font-medium">Checked In / Lobby</p>
          <p className="text-lg font-bold font-mono tabular-nums text-amber-700">{arrivedCount}</p>
          <p className="text-xs text-slate-400 mt-0.5">Ready for treatment</p>
        </div>

        <div className="bg-white p-3 rounded-lg border border-slate-200">
          <p className="text-xs text-teal-700 font-medium">In Treatment</p>
          <p className="text-lg font-bold font-mono tabular-nums text-teal-700">{inSessionCount}</p>
          <p className="text-xs text-slate-400 mt-0.5">Active on table / gym</p>
        </div>

        <div className="bg-white p-3 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-600 font-medium">Completed</p>
          <p className="text-lg font-bold font-mono tabular-nums text-slate-800">{completedCount}</p>
          <p className="text-xs text-slate-400 mt-0.5">SOAP ready / billed</p>
        </div>

        <div className="bg-white p-3 rounded-lg border border-slate-200 col-span-2 sm:col-span-1">
          <p className="text-xs text-emerald-700 font-medium">Copays Collected</p>
          <p className="text-lg font-bold font-mono tabular-nums text-emerald-700">
            ${copaysCollectedTotal}
          </p>
          <p className="text-xs text-slate-400 mt-0.5">Front desk revenue</p>
        </div>
      </div>

      {/* Main Schedule Content View */}

      {/* Mode A: By Practitioner Columns */}
      {viewMode === 'practitioner_columns' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {providers
            .filter((p) => selectedProviderFilter === 'all' || p.id === selectedProviderFilter)
            .map((provider) => {
              const provApts = filteredAppointments
                .filter((apt) => apt.providerId === provider.id)
                .sort((a, b) => a.time.localeCompare(b.time));

              return (
                <div
                  key={provider.id}
                  className="bg-white rounded-xl border border-slate-200 flex flex-col overflow-hidden"
                >
                  {/* Column Header */}
                  <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-xs"
                        style={{ backgroundColor: provider.color }}
                      >
                        {provider.avatarInitials}
                      </div>
                      <div>
                        <h3 className="text-xs font-bold text-slate-900 leading-tight">
                          {provider.name}, {provider.credentials}
                        </h3>
                        <p className="text-xs text-slate-500">{provider.specialty}</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono tabular-nums text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {provApts.length} appts
                    </span>
                  </div>

                  {/* Appointment Cards in Column */}
                  <div className="p-3 space-y-3 flex-1 overflow-y-auto min-h-[420px] bg-slate-50/30">
                    {provApts.length === 0 ? (
                      <div className="h-48 flex flex-col items-center justify-center text-center text-slate-400 border border-dashed border-slate-200 rounded-lg p-4">
                        <Clock className="w-6 h-6 mb-1 text-slate-300" />
                        <p className="text-xs font-medium">No appointments scheduled</p>
                        <button
                          onClick={() => onNewAppointmentClick('09:00', provider.id)}
                          className="mt-2 text-xs text-teal-600 hover:text-teal-800 font-semibold"
                        >
                          + Book time slot
                        </button>
                      </div>
                    ) : (
                      provApts.map((apt) => {
                        const pat = patients.find((p) => p.id === apt.patientId);
                        return (
                          <div
                            key={apt.id}
                            className={`p-3 rounded-lg border shadow-xs transition-all ${getStatusColor(
                              apt.status
                            )}`}
                          >
                            {/* Card Top: Time, Room, Status */}
                            <div className="flex items-start justify-between gap-2 mb-1.5">
                              <div className="flex items-center gap-1.5 text-xs font-mono tabular-nums font-semibold text-slate-800">
                                <Clock className="w-3.5 h-3.5 text-slate-400" />
                                <span>{apt.time}</span>
                                <span className="text-slate-400 font-normal">({apt.durationMinutes}m)</span>
                              </div>
                              <span className="text-xs text-slate-500 truncate max-w-[120px]">
                                {apt.room}
                              </span>
                            </div>

                            {/* Patient Info */}
                            <div className="mb-2">
                              <h4 className="text-xs font-bold text-slate-900 hover:text-teal-700 cursor-pointer">
                                {pat ? `${pat.lastName}, ${pat.firstName}` : 'Unknown Patient'}
                              </h4>
                              {/* Zero-Pill unboxed metadata */}
                              <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                                <span>{pat?.mrn}</span>
                                <span aria-hidden="true">·</span>
                                <span>{getModalityLabel(apt.type)}</span>
                              </div>
                              <p className="text-xs text-slate-600 mt-1 line-clamp-1 italic">
                                "{apt.chiefComplaint}"
                              </p>
                            </div>

                            {/* Action Row */}
                            <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between gap-1 flex-wrap">
                              {/* Status Transition Buttons */}
                              <div className="flex items-center gap-1">
                                {apt.status === 'scheduled' && (
                                  <button
                                    onClick={() => onUpdateStatus(apt.id, 'arrived')}
                                    className="px-2 py-0.5 text-xs font-medium text-amber-700 bg-amber-100 hover:bg-amber-200 rounded transition-colors"
                                  >
                                    Check In
                                  </button>
                                )}
                                {apt.status === 'arrived' && (
                                  <button
                                    onClick={() => onUpdateStatus(apt.id, 'in_session')}
                                    className="px-2 py-0.5 text-xs font-medium text-teal-700 bg-teal-100 hover:bg-teal-200 rounded transition-colors inline-flex items-center gap-1"
                                  >
                                    <Play className="w-3 h-3 fill-current" /> Start Visit
                                  </button>
                                )}
                                {apt.status === 'in_session' && (
                                  <button
                                    onClick={() => onUpdateStatus(apt.id, 'completed')}
                                    className="px-2 py-0.5 text-xs font-medium text-emerald-700 bg-emerald-100 hover:bg-emerald-200 rounded transition-colors inline-flex items-center gap-1"
                                  >
                                    <CheckCircle2 className="w-3 h-3" /> Complete
                                  </button>
                                )}
                                {apt.status === 'completed' && (
                                  <span className="text-xs text-slate-500 font-medium">Finished</span>
                                )}
                              </div>

                              {/* Clinical & Billing Links */}
                              <div className="flex items-center gap-1.5">
                                {apt.type === 'telehealth' && (
                                  <button
                                    onClick={() => onStartTelehealth(apt.id)}
                                    className="p-1 text-teal-700 hover:bg-teal-100 rounded transition-colors"
                                    title="Open Virtual Telehealth Room"
                                  >
                                    <Video className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                <button
                                  onClick={() => onOpenSoapNote(apt.patientId, apt.id)}
                                  className="p-1 text-slate-600 hover:text-teal-700 hover:bg-slate-100 rounded transition-colors"
                                  title="Open SOAP Encounter Chart"
                                >
                                  <FileText className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => onOpenBillingForApt(apt)}
                                  className="p-1 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded transition-colors"
                                  title="Bill Encounter / Superbill"
                                >
                                  <DollarSign className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Column Bottom Action */}
                  <div className="p-2.5 border-t border-slate-200 bg-white">
                    <button
                      onClick={() => onNewAppointmentClick(undefined, provider.id)}
                      className="w-full py-1.5 text-xs font-medium text-slate-700 hover:text-teal-700 hover:bg-slate-50 rounded border border-slate-200 transition-colors flex items-center justify-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Patient to {provider.name.split(' ')[1]}
                    </button>
                  </div>
                </div>
              );
            })}
        </div>
      )}

      {/* Mode B: By Room / Bay Columns */}
      {viewMode === 'room_columns' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {rooms.map((roomName) => {
            const roomApts = filteredAppointments
              .filter((apt) => apt.room === roomName)
              .sort((a, b) => a.time.localeCompare(b.time));

            return (
              <div key={roomName} className="bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col">
                <div className="p-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-900">{roomName}</h3>
                  <span className="text-xs font-mono tabular-nums text-slate-500">
                    {roomApts.length} appts
                  </span>
                </div>
                <div className="p-3 space-y-2.5 flex-1 min-h-[300px]">
                  {roomApts.length === 0 ? (
                    <div className="h-32 flex items-center justify-center text-xs text-slate-400">
                      Bay vacant today
                    </div>
                  ) : (
                    roomApts.map((apt) => {
                      const pat = patients.find((p) => p.id === apt.patientId);
                      const prov = providers.find((p) => p.id === apt.providerId);
                      return (
                        <div
                          key={apt.id}
                          className={`p-2.5 rounded-lg border text-xs ${getStatusColor(apt.status)}`}
                        >
                          <div className="flex items-center justify-between font-mono tabular-nums font-semibold mb-1">
                            <span>{apt.time} ({apt.durationMinutes}m)</span>
                            <span className="font-normal text-slate-500">{prov?.name}</span>
                          </div>
                          <p className="font-bold text-slate-900">
                            {pat ? `${pat.lastName}, ${pat.firstName}` : 'Patient'}
                          </p>
                          <p className="text-slate-500 text-xs mt-0.5 truncate">{apt.chiefComplaint}</p>
                          <div className="mt-2 flex items-center justify-between pt-1.5 border-t border-slate-200/50">
                            <span className="capitalize text-slate-600">{apt.status.replace('_', ' ')}</span>
                            <button
                              onClick={() => onOpenSoapNote(apt.patientId, apt.id)}
                              className="text-teal-700 hover:underline font-medium"
                            >
                              SOAP Chart
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Mode C: Day List Table View */}
      {viewMode === 'list' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Time</th>
                  <th className="py-3 px-4">Patient (MRN)</th>
                  <th className="py-3 px-4">Practitioner</th>
                  <th className="py-3 px-4">Modality & Room</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Copay</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAppointments.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      No appointments matching filters for this date.
                    </td>
                  </tr>
                ) : (
                  filteredAppointments.map((apt) => {
                    const pat = patients.find((p) => p.id === apt.patientId);
                    const prov = providers.find((p) => p.id === apt.providerId);
                    return (
                      <tr key={apt.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4 font-mono tabular-nums font-semibold text-slate-800">
                          {apt.time}
                          <span className="text-slate-400 font-normal ml-1">({apt.durationMinutes}m)</span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">
                            {pat ? `${pat.lastName}, ${pat.firstName}` : 'Patient'}
                          </div>
                          <div className="text-slate-400 text-xs font-mono">{pat?.mrn}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-700">
                          {prov?.name}
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-slate-800 font-medium">{getModalityLabel(apt.type)}</div>
                          <div className="text-slate-400 text-xs">{apt.room}</div>
                        </td>
                        <td className="py-3 px-4">
                          <select
                            value={apt.status}
                            onChange={(e) => onUpdateStatus(apt.id, e.target.value as AppointmentStatus)}
                            className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 font-medium capitalize text-slate-700 cursor-pointer"
                          >
                            <option value="scheduled">Scheduled</option>
                            <option value="arrived">Arrived</option>
                            <option value="in_session">In Session</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                            <option value="no_show">No Show</option>
                          </select>
                        </td>
                        <td className="py-3 px-4 font-mono tabular-nums">
                          {apt.copayCollected ? (
                            <span className="text-emerald-700 font-medium">${apt.copayAmount} Paid</span>
                          ) : (
                            <span className="text-amber-700 font-medium">${apt.copayAmount} Due</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          {apt.type === 'telehealth' && (
                            <button
                              onClick={() => onStartTelehealth(apt.id)}
                              className="text-teal-700 hover:text-teal-900 font-medium inline-flex items-center gap-1"
                            >
                              <Video className="w-3.5 h-3.5" /> Telehealth
                            </button>
                          )}
                          <button
                            onClick={() => onOpenSoapNote(apt.patientId, apt.id)}
                            className="text-slate-700 hover:text-teal-700 font-medium"
                          >
                            SOAP Note
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
