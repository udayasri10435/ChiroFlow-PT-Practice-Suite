import React, { useState } from 'react';
import { 
  DollarSign, 
  FileText, 
  Search, 
  Plus, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Printer, 
  CreditCard,
  Building,
  TrendingUp,
  Receipt
} from 'lucide-react';
import { Claim, Patient, Provider, ClaimStatus } from '../../types';
import { CPT_CODE_DATABASE } from '../../utils/billingUtils';
import { CMS1500Modal } from './CMS1500Modal';
import { NewClaimModal } from './NewClaimModal';

interface BillingModuleProps {
  claims: Claim[];
  patients: Patient[];
  providers: Provider[];
  onSaveClaim: (claim: Claim) => void;
  onUpdateClaimStatus: (claimId: string, status: ClaimStatus) => void;
  onRecordCopayPayment: (patientId: string, amount: number) => void;
}

export const BillingModule: React.FC<BillingModuleProps> = ({
  claims,
  patients,
  providers,
  onSaveClaim,
  onUpdateClaimStatus,
  onRecordCopayPayment,
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClaimForCMS, setSelectedClaimForCMS] = useState<Claim | null>(null);
  const [isNewClaimOpen, setIsNewClaimOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'claims' | 'fee_schedule' | 'ledger'>('claims');

  // Filtered claims
  const filteredClaims = claims.filter((claim) => {
    if (statusFilter !== 'all' && claim.status !== statusFilter) return false;
    if (searchTerm) {
      const pat = patients.find(p => p.id === claim.patientId);
      const patName = `${pat?.firstName} ${pat?.lastName}`.toLowerCase();
      const claimNum = claim.claimNumber.toLowerCase();
      const payer = claim.insurancePayer.toLowerCase();
      const term = searchTerm.toLowerCase();
      return patName.includes(term) || claimNum.includes(term) || payer.includes(term);
    }
    return true;
  });

  // Calculate high-level financial metrics
  const totalBilled = claims.reduce((sum, c) => sum + c.totalCharges, 0);
  const totalCollected = claims.reduce((sum, c) => sum + (c.insurancePaidAmount || 0) + (c.patientResponsibility || 0), 0);
  const pendingInsurance = claims
    .filter(c => c.status === 'submitted' || c.status === 'in_review')
    .reduce((sum, c) => sum + (c.totalCharges - c.patientResponsibility), 0);
  const draftClaimsCount = claims.filter(c => c.status === 'draft').length;

  return (
    <div className="space-y-6">
      
      {/* Financial Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold">Total Encounters Billed</span>
            <Receipt className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-xl font-bold font-mono tabular-nums text-slate-900">
            ${totalBilled.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-slate-500 mt-1">Across {claims.length} claims</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold text-emerald-800">Total Revenue Collected</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xl font-bold font-mono tabular-nums text-emerald-700">
            ${totalCollected.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-slate-500 mt-1">Insurance ERA & Patient Copays</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold text-amber-800">Pending in Clearinghouse</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-xl font-bold font-mono tabular-nums text-amber-800">
            ${pendingInsurance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-slate-500 mt-1">Awaiting 835 Remittance</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-semibold text-teal-800">Draft Superbills</span>
            <FileText className="w-4 h-4 text-teal-600" />
          </div>
          <p className="text-xl font-bold font-mono tabular-nums text-teal-800">
            {draftClaimsCount}
          </p>
          <p className="text-xs text-slate-500 mt-1">Ready for scrubber review</p>
        </div>
      </div>

      {/* Main Tab Controls & Top Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200">
        
        {/* Navigation Tabs */}
        <div className="flex items-center p-1 bg-slate-100 rounded-lg border border-slate-200">
          <button
            onClick={() => setActiveTab('claims')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'claims'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Claims & Superbills ({claims.length})
          </button>
          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'ledger'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Patient Copay Ledger
          </button>
          <button
            onClick={() => setActiveTab('fee_schedule')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'fee_schedule'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Chiro & PT Fee Schedule
          </button>
        </div>

        {/* Action Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsNewClaimOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" /> + New Claim / Superbill
          </button>
        </div>
      </div>

      {/* View 1: Claims & Superbills */}
      {activeTab === 'claims' && (
        <div className="space-y-4">
          
          {/* Search & Status Filter Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {/* Interactive Status Segmented Filter */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
              {[
                { id: 'all', label: 'All Claims' },
                { id: 'draft', label: 'Draft' },
                { id: 'submitted', label: 'Submitted' },
                { id: 'in_review', label: 'In Review' },
                { id: 'paid', label: 'Paid' },
                { id: 'denied', label: 'Denied' },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setStatusFilter(item.id)}
                  className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                    statusFilter === item.id
                      ? 'bg-slate-900 text-white font-semibold'
                      : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Live Search Input */}
            <div className="relative w-full sm:w-72">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search patient, claim #, or payer..."
                className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>
          </div>

          {/* Claims High Density Grid */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Claim #</th>
                    <th className="py-3 px-4">Date & Patient</th>
                    <th className="py-3 px-4">Insurance Payer</th>
                    <th className="py-3 px-4">Procedures (CPT)</th>
                    <th className="py-3 px-4 text-right">Billed ($)</th>
                    <th className="py-3 px-4 text-right">Paid ($)</th>
                    <th className="py-3 px-4">Claim Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredClaims.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        No claims found matching selected filter.
                      </td>
                    </tr>
                  ) : (
                    filteredClaims.map((claim) => {
                      const pat = patients.find(p => p.id === claim.patientId);
                      const prov = providers.find(p => p.id === claim.providerId);
                      return (
                        <tr key={claim.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4">
                            <span className="font-mono font-bold text-slate-900">{claim.claimNumber}</span>
                            <div className="text-[10px] text-slate-400 font-mono">Filing: {claim.filingDate}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-900">
                              {pat ? `${pat.lastName}, ${pat.firstName}` : 'Patient'}
                            </div>
                            {/* Zero-Pill unboxed metadata */}
                            <div className="text-slate-500 text-xs flex items-center gap-1.5 mt-0.5">
                              <span className="font-mono tabular-nums">{claim.serviceDate}</span>
                              <span aria-hidden="true">·</span>
                              <span>{prov?.name.split(' ')[1]}</span>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-slate-800 font-medium">{claim.insurancePayer}</div>
                            <div className="text-slate-400 text-xs font-mono">Policy: {claim.policyNumber}</div>
                          </td>
                          <td className="py-3 px-4 font-mono">
                            <div className="flex flex-wrap gap-1">
                              {claim.lines.map((l, i) => (
                                <span
                                  key={i}
                                  className="text-xs bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded border border-slate-200"
                                >
                                  {l.cptCode}{l.modifier ? `-${l.modifier}` : ''}
                                </span>
                              ))}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-slate-900">
                            ${claim.totalCharges.toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums">
                            {claim.insurancePaidAmount > 0 ? (
                              <span className="text-emerald-700 font-bold">${claim.insurancePaidAmount.toFixed(2)}</span>
                            ) : (
                              <span className="text-slate-400">$0.00</span>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <select
                              value={claim.status}
                              onChange={(e) => onUpdateClaimStatus(claim.id, e.target.value as ClaimStatus)}
                              className="text-xs bg-slate-50 border border-slate-200 rounded px-2 py-1 font-semibold uppercase text-slate-700 cursor-pointer"
                            >
                              <option value="draft">Draft</option>
                              <option value="scrubbed">Scrubbed</option>
                              <option value="submitted">Submitted</option>
                              <option value="in_review">In Review</option>
                              <option value="paid">Paid</option>
                              <option value="denied">Denied</option>
                            </select>
                          </td>
                          <td className="py-3 px-4 text-right space-x-1.5">
                            <button
                              onClick={() => setSelectedClaimForCMS(claim)}
                              className="px-2.5 py-1 text-xs font-medium text-teal-700 bg-teal-50 hover:bg-teal-100 rounded transition-colors inline-flex items-center gap-1"
                            >
                              <Printer className="w-3 h-3" /> CMS-1500
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* View 2: Patient Copay & Self-Pay Ledger */}
      {activeTab === 'ledger' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs p-5">
          <div className="mb-4">
            <h3 className="text-sm font-bold text-slate-900">Patient Copay & Cost-Sharing Ledger</h3>
            <p className="text-xs text-slate-500 mt-0.5">Track patient deductible responsibility, copays, and collect payments</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="py-3 px-4">Patient Name (MRN)</th>
                  <th className="py-3 px-4">Primary Payer</th>
                  <th className="py-3 px-4 font-mono text-center">Required Copay</th>
                  <th className="py-3 px-4 font-mono text-center">Deductible Left</th>
                  <th className="py-3 px-4 font-mono text-center">Visits Authorized</th>
                  <th className="py-3 px-4 text-right">Collect Copay</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {patients.map(pat => (
                  <tr key={pat.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-semibold text-slate-900">
                      {pat.lastName}, {pat.firstName}
                      <span className="text-slate-400 font-mono text-xs block font-normal">{pat.mrn}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-700">
                      {pat.insurance.payerName}
                    </td>
                    <td className="py-3 px-4 font-mono text-center tabular-nums font-bold text-slate-800">
                      ${pat.insurance.copayAmount}
                    </td>
                    <td className="py-3 px-4 font-mono text-center tabular-nums text-slate-600">
                      ${pat.insurance.deductibleRemaining}
                    </td>
                    <td className="py-3 px-4 font-mono text-center tabular-nums">
                      <span className="text-teal-700 font-semibold">{pat.insurance.visitsUsed || 0}</span> / {pat.insurance.visitsAuthorized || 20}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onRecordCopayPayment(pat.id, pat.insurance.copayAmount)}
                        className="px-3 py-1 text-xs font-medium text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded transition-colors inline-flex items-center gap-1"
                      >
                        <CreditCard className="w-3.5 h-3.5" /> Collect ${pat.insurance.copayAmount}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View 3: Chiro & PT Fee Schedule Reference */}
      {activeTab === 'fee_schedule' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs p-5">
          <div className="mb-4">
            <h3 className="text-sm font-bold text-slate-900">Master Fee Schedule & CPT RVU References</h3>
            <p className="text-xs text-slate-500 mt-0.5">Standard clinic charges vs Medicare / Commercial allowed reimbursement thresholds</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-4">CPT Code</th>
                  <th className="py-2.5 px-4">Category</th>
                  <th className="py-2.5 px-4">Official Description</th>
                  <th className="py-2.5 px-4 text-right">Standard Fee ($)</th>
                  <th className="py-2.5 px-4 text-right">Allowed Baseline ($)</th>
                  <th className="py-2.5 px-4 text-center">Required Modifier</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {CPT_CODE_DATABASE.map(cpt => (
                  <tr key={cpt.code} className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-bold text-slate-900">{cpt.code}</td>
                    <td className="py-2.5 px-4 font-sans text-xs text-slate-600">{cpt.category}</td>
                    <td className="py-2.5 px-4 font-sans text-xs text-slate-700 max-w-md">{cpt.description}</td>
                    <td className="py-2.5 px-4 text-right tabular-nums font-bold text-slate-900">${cpt.defaultCharge.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-right tabular-nums text-emerald-700">${cpt.standardMedicareAllowed.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-center">
                      {cpt.typicalModifiers.length > 0 ? (
                        cpt.typicalModifiers.map(m => (
                          <span key={m} className="px-1.5 py-0.5 bg-slate-100 text-slate-800 rounded mr-1 text-[10px]">
                            -{m}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-400 font-sans">None</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CMS-1500 Form Modal */}
      {selectedClaimForCMS && (
        <CMS1500Modal
          isOpen={!!selectedClaimForCMS}
          onClose={() => setSelectedClaimForCMS(null)}
          claim={selectedClaimForCMS}
          patient={patients.find(p => p.id === selectedClaimForCMS.patientId)}
          provider={providers.find(p => p.id === selectedClaimForCMS.providerId)}
          onUpdateStatus={onUpdateClaimStatus}
        />
      )}

      {/* New Claim Creator Modal */}
      {isNewClaimOpen && (
        <NewClaimModal
          isOpen={isNewClaimOpen}
          onClose={() => setIsNewClaimOpen(false)}
          onSave={onSaveClaim}
          patients={patients}
          providers={providers}
        />
      )}
    </div>
  );
};
