import React from 'react';
import { X, Printer, CheckCircle2, AlertTriangle, ShieldCheck, Download, DollarSign } from 'lucide-react';
import { Claim, Patient, Provider } from '../../types';
import { CLINIC_INFO } from '../../data/mockData';
import { scrubClaim } from '../../utils/billingUtils';

interface CMS1500ModalProps {
  isOpen: boolean;
  onClose: () => void;
  claim: Claim;
  patient?: Patient;
  provider?: Provider;
  onUpdateStatus: (claimId: string, status: any) => void;
}

export const CMS1500Modal: React.FC<CMS1500ModalProps> = ({
  isOpen,
  onClose,
  claim,
  patient,
  provider,
  onUpdateStatus,
}) => {
  if (!isOpen || !claim) return null;

  const scrubResults = scrubClaim(claim.lines);

  const handlePrint = () => {
    window.print();
  };

  const handleScrubAndSubmit = () => {
    if (scrubResults.passed) {
      onUpdateStatus(claim.id, 'submitted');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-4xl rounded-xl shadow-2xl border border-slate-300 flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Top Control Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-slate-200 bg-slate-50 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-2 py-0.5 bg-red-100 text-red-800 rounded">
                CMS-1500 (02/12)
              </span>
              <h2 className="text-sm font-bold text-slate-900">
                Health Insurance Claim Form · {claim.claimNumber}
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Standard paper & electronic 837P claim representation for {patient?.firstName} {patient?.lastName}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" /> Print Superbill / Form
            </button>
            
            {claim.status === 'draft' || claim.status === 'scrubbed' ? (
              <button
                onClick={handleScrubAndSubmit}
                disabled={!scrubResults.passed}
                className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white rounded-lg transition-colors shadow-xs ${
                  scrubResults.passed
                    ? 'bg-teal-600 hover:bg-teal-700'
                    : 'bg-slate-400 cursor-not-allowed'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" /> Submit to Clearinghouse
              </button>
            ) : (
              <span className="text-xs font-mono uppercase font-semibold text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                Status: {claim.status}
              </span>
            )}

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-200 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Claim Scrubber Audit Status */}
        <div className="px-6 py-2.5 bg-slate-100/80 border-b border-slate-200 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-2">
            {scrubResults.passed ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span className="font-semibold text-emerald-900">Claim Scrubber Passed:</span>
                <span className="text-slate-600">CCI edits verified, modifiers valid, NPI matching billing entity.</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span className="font-semibold text-rose-900">Scrubber Warnings / Errors:</span>
                <span className="text-rose-700">{scrubResults.errors.join('; ')}</span>
              </>
            )}
          </div>
          <div className="font-mono tabular-nums text-slate-700 font-semibold">
            Total Charge: ${claim.totalCharges.toFixed(2)}
          </div>
        </div>

        {/* CMS-1500 Graphic Form Container */}
        <div className="p-6 overflow-y-auto bg-amber-50/20 space-y-4 text-[11px] font-sans">
          
          {/* Header Insurance Indicator Box */}
          <div className="border border-red-800 p-2 bg-white rounded">
            <div className="flex items-center justify-between border-b border-red-200 pb-1 mb-2">
              <span className="font-bold text-red-900">1. MEDICARE / MEDICAID / TRICARE / GROUP HEALTH PLAN</span>
              <span className="font-bold text-red-900">1a. INSURED'S I.D. NUMBER:</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium text-slate-800">
                Primary Payer: {claim.insurancePayer} (Payer ID: {claim.payerId})
              </span>
              <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                {claim.policyNumber}
              </span>
            </div>
          </div>

          {/* Patient Demographics & Insured Data */}
          <div className="grid grid-cols-2 gap-3">
            <div className="border border-red-800 p-2.5 bg-white rounded space-y-1">
              <div className="font-bold text-red-900 text-[10px]">2. PATIENT'S NAME (Last, First, Middle)</div>
              <div className="font-semibold text-slate-900 text-xs">
                {patient ? `${patient.lastName}, ${patient.firstName}` : 'Miller, Jonathan'}
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
                <div>
                  <span className="font-bold text-red-900 text-[10px]">3. PATIENT BIRTH DATE</span>
                  <div className="font-mono text-slate-800">{patient?.dob}</div>
                </div>
                <div>
                  <span className="font-bold text-red-900 text-[10px]">SEX</span>
                  <div className="text-slate-800">{patient?.gender}</div>
                </div>
              </div>
              <div className="pt-1 border-t border-slate-100">
                <span className="font-bold text-red-900 text-[10px]">5. PATIENT ADDRESS</span>
                <div className="text-slate-800">{patient?.address}</div>
              </div>
            </div>

            <div className="border border-red-800 p-2.5 bg-white rounded space-y-1">
              <div className="font-bold text-red-900 text-[10px]">11. INSURED'S POLICY GROUP OR FECA NUMBER</div>
              <div className="font-mono text-slate-900 font-semibold">{claim.groupNumber}</div>
              <div className="pt-1 border-t border-slate-100">
                <span className="font-bold text-red-900 text-[10px]">11a. INSURED'S DATE OF BIRTH</span>
                <div className="text-slate-800">{patient?.dob}</div>
              </div>
              <div className="pt-1 border-t border-slate-100">
                <span className="font-bold text-red-900 text-[10px]">PRIOR AUTHORIZATION NUMBER</span>
                <div className="font-mono text-slate-900">{patient?.insurance.preAuthNumber || 'N/A'}</div>
              </div>
            </div>
          </div>

          {/* Box 21: Diagnosis ICD-10 Codes */}
          <div className="border border-red-800 p-2.5 bg-white rounded">
            <div className="font-bold text-red-900 mb-1">
              21. DIAGNOSIS OR NATURE OF ILLNESS OR INJURY (ICD-10-CM)
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {claim.icd10Codes.map((diag, index) => {
                const pointerLetter = String.fromCharCode(65 + index); // A, B, C, D
                return (
                  <div key={diag.code} className="border border-slate-200 p-1.5 rounded bg-slate-50">
                    <span className="font-bold text-red-800 mr-1.5">{pointerLetter}.</span>
                    <span className="font-mono font-bold text-slate-900">{diag.code}</span>
                    <p className="text-[10px] text-slate-500 truncate mt-0.5">{diag.description}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Box 24: Six Lines of Service (CPT / Modifiers / Units / Charges) */}
          <div className="border border-red-800 bg-white rounded overflow-hidden">
            <div className="p-2 bg-red-800 text-white font-bold text-[11px] flex justify-between items-center">
              <span>24. LINES OF SERVICE · DATES OF SERVICE, CPT/HCPCS, MODIFIERS, DIAG POINTERS, CHARGES</span>
              <span>POS: 11 (Office)</span>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-100 border-b border-red-200 text-slate-700 text-[10px] uppercase font-semibold">
                  <tr>
                    <th className="p-1.5 border-r border-slate-200">24A. Date(s) of Svc</th>
                    <th className="p-1.5 border-r border-slate-200">24B. POS</th>
                    <th className="p-1.5 border-r border-slate-200">24D. CPT / HCPCS & Modifiers</th>
                    <th className="p-1.5 border-r border-slate-200">24E. Diag Pointer</th>
                    <th className="p-1.5 border-r border-slate-200">24F. $ Charges</th>
                    <th className="p-1.5 border-r border-slate-200">24G. Days/Units</th>
                    <th className="p-1.5">24J. Rendering NPI</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-xs">
                  {claim.lines.map((line, idx) => (
                    <tr key={line.id || idx} className="hover:bg-slate-50">
                      <td className="p-2 border-r border-slate-200 tabular-nums">
                        {claim.serviceDate}
                      </td>
                      <td className="p-2 border-r border-slate-200 text-center">11</td>
                      <td className="p-2 border-r border-slate-200">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900">
                          <span>{line.cptCode}</span>
                          {line.modifier && (
                            <span className="text-red-700 bg-red-50 px-1 py-0.2 rounded border border-red-200 text-[10px]">
                              -{line.modifier}
                            </span>
                          )}
                        </div>
                        <div className="font-sans text-[10px] text-slate-500 truncate max-w-xs">
                          {line.description}
                        </div>
                      </td>
                      <td className="p-2 border-r border-slate-200 text-center font-bold text-red-900">
                        {line.diagPointer}
                      </td>
                      <td className="p-2 border-r border-slate-200 text-right tabular-nums font-semibold">
                        ${line.totalCharge.toFixed(2)}
                      </td>
                      <td className="p-2 border-r border-slate-200 text-center tabular-nums">
                        {line.units}
                      </td>
                      <td className="p-2 text-slate-700">
                        {provider?.npi || CLINIC_INFO.npi}
                      </td>
                    </tr>
                  ))}
                  {/* Padding empty row to match 1500 layout standard */}
                  <tr className="text-slate-300">
                    <td className="p-2 border-r border-slate-200">--</td>
                    <td className="p-2 border-r border-slate-200 text-center">--</td>
                    <td className="p-2 border-r border-slate-200">[Unused Service Line]</td>
                    <td className="p-2 border-r border-slate-200 text-center">--</td>
                    <td className="p-2 border-r border-slate-200 text-right">0.00</td>
                    <td className="p-2 border-r border-slate-200 text-center">0</td>
                    <td className="p-2">--</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Bottom Financial & Billing Entity Verification */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="border border-red-800 p-2.5 bg-white rounded space-y-1">
              <span className="font-bold text-red-900 text-[10px]">25. FEDERAL TAX I.D. NUMBER</span>
              <div className="font-mono text-slate-900 font-semibold">{CLINIC_INFO.taxId}</div>
              <div className="pt-1 border-t border-slate-100">
                <span className="font-bold text-red-900 text-[10px]">31. SIGNATURE OF PHYSICIAN / SUPPLIER</span>
                <div className="italic font-serif text-slate-800 text-xs">
                  {provider ? `${provider.name}, ${provider.credentials}` : 'Dr. Marcus Vance, DC'}
                </div>
              </div>
            </div>

            <div className="border border-red-800 p-2.5 bg-white rounded space-y-1">
              <span className="font-bold text-red-900 text-[10px]">32. SERVICE FACILITY LOCATION</span>
              <div className="text-slate-800 font-semibold">{CLINIC_INFO.name}</div>
              <div className="text-slate-500 text-[10px]">{CLINIC_INFO.address}</div>
              <div className="font-mono text-slate-700 text-[10px]">NPI: {CLINIC_INFO.npi}</div>
            </div>

            <div className="border border-red-800 p-2.5 bg-white rounded space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-red-900">28. TOTAL CHARGE:</span>
                <span className="font-mono font-bold text-slate-900">${claim.totalCharges.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-red-900">29. PATIENT COPAY PAID:</span>
                <span className="font-mono text-emerald-700 font-semibold">${claim.patientResponsibility.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-xs pt-1 border-t border-red-100">
                <span className="font-bold text-red-900">30. BALANCE DUE (PAYER):</span>
                <span className="font-mono font-bold text-teal-800">
                  ${(claim.totalCharges - claim.patientResponsibility).toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-500">
            Filing Date: {claim.filingDate} · Payer Route: Availity / Change Healthcare EDI Gateway
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-lg transition-colors"
          >
            Close Form
          </button>
        </div>
      </div>
    </div>
  );
};
