import React, { useState } from 'react';
import { X, Plus, Trash2, ShieldAlert, Check, DollarSign } from 'lucide-react';
import { Patient, Provider, Claim, ClaimLineItem } from '../../types';
import { CPT_CODE_DATABASE, scrubClaim } from '../../utils/billingUtils';

interface NewClaimModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (claim: Claim) => void;
  patients: Patient[];
  providers: Provider[];
  initialPatientId?: string;
  initialProviderId?: string;
  initialDate?: string;
}

export const NewClaimModal: React.FC<NewClaimModalProps> = ({
  isOpen,
  onClose,
  onSave,
  patients,
  providers,
  initialPatientId,
  initialProviderId,
  initialDate = '2026-09-29',
}) => {
  const [patientId, setPatientId] = useState(initialPatientId || patients[0]?.id || '');
  const [providerId, setProviderId] = useState(initialProviderId || providers[0]?.id || '');
  const [serviceDate, setServiceDate] = useState(initialDate);
  const [lines, setLines] = useState<ClaimLineItem[]>([
    {
      id: 'ln-init-1',
      cptCode: '98941',
      description: 'Chiropractic manipulative treatment (CMT); spinal, 3-4 regions',
      units: 1,
      chargePerUnit: 85,
      totalCharge: 85,
      allowedAmount: 58.20,
      copayApplied: 25,
      diagPointer: 'A',
    },
  ]);

  const selectedPatient = patients.find(p => p.id === patientId);

  // Add line item
  const handleAddCode = (cptCode: string) => {
    const def = CPT_CODE_DATABASE.find(c => c.code === cptCode);
    if (!def) return;

    // Check if modifier 59 is needed for 97140
    let modifier = def.typicalModifiers[0] || undefined;
    const hasCmt = lines.some(l => ['98940', '98941', '98942'].includes(l.cptCode));
    if (def.code === '97140' && hasCmt) {
      modifier = '59';
    }

    const newLine: ClaimLineItem = {
      id: `ln-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      cptCode: def.code,
      description: def.description,
      modifier,
      units: 1,
      chargePerUnit: def.defaultCharge,
      totalCharge: def.defaultCharge,
      allowedAmount: def.standardMedicareAllowed,
      copayApplied: 0,
      diagPointer: 'A',
    };

    setLines(prev => [...prev, newLine]);
  };

  const handleRemoveLine = (id: string) => {
    setLines(lines.filter(l => l.id !== id));
  };

  const handleUpdateLine = (id: string, field: keyof ClaimLineItem, value: any) => {
    setLines(lines.map(line => {
      if (line.id !== id) return line;
      const updated = { ...line, [field]: value };
      if (field === 'units' || field === 'chargePerUnit') {
        updated.totalCharge = Number(updated.units) * Number(updated.chargePerUnit);
      }
      return updated;
    }));
  };

  const totalCharges = lines.reduce((sum, l) => sum + (Number(l.totalCharge) || 0), 0);
  const patientCopay = selectedPatient?.insurance.copayAmount || 0;
  const scrubResult = scrubClaim(lines);

  if (!isOpen) return null;

  const handleSubmit = (submitStatus: 'draft' | 'submitted') => {
    if (!selectedPatient) return;

    const newClaim: Claim = {
      id: `clm-${Date.now()}`,
      claimNumber: `CLM-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      patientId,
      providerId,
      serviceDate,
      filingDate: new Date().toISOString().split('T')[0],
      insurancePayer: selectedPatient.insurance.payerName,
      payerId: selectedPatient.insurance.payerId,
      policyNumber: selectedPatient.insurance.policyId,
      groupNumber: selectedPatient.insurance.groupNumber,
      icd10Codes: selectedPatient.diagnoses,
      lines,
      totalCharges,
      patientResponsibility: patientCopay,
      insurancePaidAmount: 0,
      status: submitStatus,
      scrubErrors: scrubResult.errors,
    };

    onSave(newClaim);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white w-full max-w-3xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Create Encounter Claim / Superbill</h2>
            <p className="text-xs text-slate-500">Assign CPT procedure codes, diagnosis pointers, and apply CCI modifiers</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          
          {/* Patient, Provider, Date Header Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Patient</label>
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-white"
              >
                {patients.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.lastName}, {p.firstName} ({p.mrn})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Rendering Clinician</label>
              <select
                value={providerId}
                onChange={(e) => setProviderId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800 bg-white"
              >
                {providers.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name}, {p.credentials}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Service</label>
              <input
                type="date"
                value={serviceDate}
                onChange={(e) => setServiceDate(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono tabular-nums border border-slate-300 rounded-lg text-slate-800"
              />
            </div>
          </div>

          {/* Patient Insurance & Diagnoses summary */}
          {selectedPatient && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
              <div className="flex items-center justify-between text-slate-700">
                <span className="font-semibold">{selectedPatient.insurance.payerName} · Policy: {selectedPatient.insurance.policyId}</span>
                <span className="font-mono tabular-nums">Copay: ${selectedPatient.insurance.copayAmount}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500 flex-wrap">
                <span className="font-medium text-slate-700">Diagnosis Pointers:</span>
                {selectedPatient.diagnoses.map((d, i) => (
                  <span key={d.code} className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-700">
                    {String.fromCharCode(65 + i)}: {d.code} ({d.description.slice(0, 30)}...)
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Quick Procedure Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Quick Add Common CPT Procedures:
            </label>
            <div className="flex flex-wrap gap-1.5">
              {CPT_CODE_DATABASE.map(cpt => (
                <button
                  key={cpt.code}
                  type="button"
                  onClick={() => handleAddCode(cpt.code)}
                  className="px-2.5 py-1 text-xs border border-slate-300 bg-white hover:bg-teal-50 hover:border-teal-400 hover:text-teal-800 rounded-md transition-colors text-slate-700 font-mono"
                >
                  +{cpt.code} (${cpt.defaultCharge})
                </button>
              ))}
            </div>
          </div>

          {/* Service Line Items Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="py-2 px-3">CPT Code</th>
                  <th className="py-2 px-3">Description</th>
                  <th className="py-2 px-2 text-center">Mod</th>
                  <th className="py-2 px-2 text-center">Diag</th>
                  <th className="py-2 px-2 text-center">Units</th>
                  <th className="py-2 px-3 text-right">Fee ($)</th>
                  <th className="py-2 px-3 text-right">Total ($)</th>
                  <th className="py-2 px-2 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {lines.map((line) => (
                  <tr key={line.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-bold text-slate-900">
                      {line.cptCode}
                    </td>
                    <td className="py-2 px-3 font-sans text-xs text-slate-600 truncate max-w-[200px]">
                      {line.description}
                    </td>
                    <td className="py-2 px-2 text-center">
                      <input
                        type="text"
                        maxLength={4}
                        placeholder="--"
                        value={line.modifier || ''}
                        onChange={(e) => handleUpdateLine(line.id, 'modifier', e.target.value.toUpperCase())}
                        className="w-12 text-center border border-slate-300 rounded py-0.5 text-xs text-red-800 font-bold uppercase"
                      />
                    </td>
                    <td className="py-2 px-2 text-center">
                      <select
                        value={line.diagPointer}
                        onChange={(e) => handleUpdateLine(line.id, 'diagPointer', e.target.value)}
                        className="text-xs border border-slate-300 rounded py-0.5 px-1 font-bold text-slate-800"
                      >
                        <option value="A">A</option>
                        <option value="AB">AB</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                      </select>
                    </td>
                    <td className="py-2 px-2 text-center">
                      <input
                        type="number"
                        min="1"
                        max="8"
                        value={line.units}
                        onChange={(e) => handleUpdateLine(line.id, 'units', Number(e.target.value))}
                        className="w-12 text-center border border-slate-300 rounded py-0.5 text-xs font-mono"
                      />
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-600">
                      ${line.chargePerUnit.toFixed(2)}
                    </td>
                    <td className="py-2 px-3 text-right font-bold text-slate-900 tabular-nums">
                      ${line.totalCharge.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveLine(line.id)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Scrubber Alert */}
          {!scrubResult.passed && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Claim Scrubber Warnings:</p>
                <ul className="list-disc list-inside mt-0.5 space-y-0.5">
                  {scrubResult.errors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Financial Totals */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500">Patient Copay:</span>{' '}
              <span className="font-bold font-mono text-emerald-700">${patientCopay.toFixed(2)}</span>
            </div>
            <div>
              <span className="text-slate-500">Expected Insurance Allowed:</span>{' '}
              <span className="font-bold font-mono text-slate-800">
                ${lines.reduce((s, l) => s + (l.allowedAmount || 0), 0).toFixed(2)}
              </span>
            </div>
            <div>
              <span className="text-slate-500">Total Billed Charges:</span>{' '}
              <span className="font-bold font-mono text-base text-slate-900">${totalCharges.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-3.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-200 rounded-lg"
          >
            Cancel
          </button>
          
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleSubmit('draft')}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Save as Draft
            </button>
            <button
              type="button"
              onClick={() => handleSubmit('submitted')}
              className="px-5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors shadow-xs"
            >
              Scrub & Submit Claim
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
