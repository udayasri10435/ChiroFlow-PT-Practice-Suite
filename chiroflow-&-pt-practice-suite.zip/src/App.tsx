/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/common/Header';
import { ScheduleModule } from './components/scheduling/ScheduleModule';
import { NewAppointmentModal } from './components/scheduling/NewAppointmentModal';
import { BillingModule } from './components/billing/BillingModule';
import { OutcomesModule } from './components/outcomes/OutcomesModule';
import { TelehealthModule } from './components/telehealth/TelehealthModule';
import { PatientChartModule } from './components/patients/PatientChartModule';
import { SoapNoteModal } from './components/patients/SoapNoteModal';
import { NewClaimModal } from './components/billing/NewClaimModal';

import {
  loadPatients,
  savePatients,
  loadAppointments,
  saveAppointments,
  loadClaims,
  saveClaims,
  loadSoapNotes,
  saveSoapNotes,
  loadOutcomes,
  saveOutcomes,
  resetClinicData,
} from './utils/storage';

import { MOCK_PROVIDERS, CLINIC_INFO } from './data/mockData';
import { 
  Appointment, 
  AppointmentStatus, 
  Claim, 
  ClaimStatus, 
  OutcomeMeasure, 
  SoapNote, 
  Patient 
} from './types';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  // Navigation & Date
  const [activeTab, setActiveTab] = useState<string>('schedule');
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-29');
  const [selectedProviderFilter, setSelectedProviderFilter] = useState<string>('all');

  // Core Data Stores with Persistence
  const [patients, setPatients] = useState<Patient[]>(() => loadPatients());
  const [appointments, setAppointments] = useState<Appointment[]>(() => loadAppointments());
  const [claims, setClaims] = useState<Claim[]>(() => loadClaims());
  const [soapNotes, setSoapNotes] = useState<SoapNote[]>(() => loadSoapNotes());
  const [outcomes, setOutcomes] = useState<OutcomeMeasure[]>(() => loadOutcomes());

  // Cross-Module Interaction State
  const [activePatientId, setActivePatientId] = useState<string>(patients[0]?.id || '');
  const [activeTelehealthAptId, setActiveTelehealthAptId] = useState<string>('');

  // Modals
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [newAptInitialTime, setNewAptInitialTime] = useState<string | undefined>();
  const [newAptInitialProvId, setNewAptInitialProvId] = useState<string | undefined>();

  const [activeSoapModalPatientId, setActiveSoapModalPatientId] = useState<string | null>(null);
  const [activeSoapModalAptId, setActiveSoapModalAptId] = useState<string | undefined>();

  const [isQuickClaimOpen, setIsQuickClaimOpen] = useState(false);
  const [quickClaimPatientId, setQuickClaimPatientId] = useState<string | undefined>();

  // Feedback Notification Banner
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Sync to localStorage
  useEffect(() => {
    savePatients(patients);
  }, [patients]);

  useEffect(() => {
    saveAppointments(appointments);
  }, [appointments]);

  useEffect(() => {
    saveClaims(claims);
  }, [claims]);

  useEffect(() => {
    saveSoapNotes(soapNotes);
  }, [soapNotes]);

  useEffect(() => {
    saveOutcomes(outcomes);
  }, [outcomes]);

  // Handlers
  const handleResetData = () => {
    if (confirm('Reset practice database to initial clinical demonstration data?')) {
      resetClinicData();
      setPatients(loadPatients());
      setAppointments(loadAppointments());
      setClaims(loadClaims());
      setSoapNotes(loadSoapNotes());
      setOutcomes(loadOutcomes());
      showNotification('Practice demonstration data reset successfully.');
    }
  };

  const handleUpdateAppointmentStatus = (aptId: string, status: AppointmentStatus) => {
    setAppointments(prev => prev.map(a => (a.id === aptId ? { ...a, status } : a)));
    showNotification(`Appointment status updated to ${status.replace('_', ' ')}.`);
  };

  const handleSaveAppointment = (apt: Appointment) => {
    setAppointments(prev => [apt, ...prev]);
    showNotification(`New appointment booked for ${apt.time}.`);
  };

  const handleSaveClaim = (claim: Claim) => {
    setClaims(prev => [claim, ...prev]);
    showNotification(`Superbill & Claim ${claim.claimNumber} generated.`);
  };

  const handleUpdateClaimStatus = (claimId: string, status: ClaimStatus) => {
    setClaims(prev => prev.map(c => (c.id === claimId ? { ...c, status } : c)));
    showNotification(`Claim ${claimId} status updated to ${status}.`);
  };

  const handleRecordCopay = (patientId: string, amount: number) => {
    // Update patient copay collected
    showNotification(`Receipt issued: $${amount.toFixed(2)} patient copay recorded.`);
  };

  const handleSaveOutcome = (outcome: OutcomeMeasure) => {
    setOutcomes(prev => [outcome, ...prev]);
    showNotification(`${outcome.type} assessment recorded with score ${outcome.percentageScore}%.`);
  };

  const handleSaveSoapNote = (note: SoapNote) => {
    const existingIndex = soapNotes.findIndex(n => n.id === note.id);
    if (existingIndex >= 0) {
      const copy = [...soapNotes];
      copy[existingIndex] = note;
      setSoapNotes(copy);
    } else {
      setSoapNotes(prev => [note, ...prev]);
    }

    // Update patient last visit and VAS score
    setPatients(prev => prev.map(p => {
      if (p.id === note.patientId) {
        return {
          ...p,
          lastVisitDate: note.date,
          currentPainVas: note.subjective.vasScore,
          totalVisits: p.totalVisits + 1,
        };
      }
      return p;
    }));

    showNotification(note.signed ? 'SOAP note signed and locked in medical record.' : 'Draft SOAP note saved.');
  };

  // Cross-Navigation Actions
  const handleOpenSoapNote = (patientId: string, appointmentId: string) => {
    setActivePatientId(patientId);
    setActiveSoapModalPatientId(patientId);
    setActiveSoapModalAptId(appointmentId);
  };

  const handleStartTelehealth = (appointmentId: string) => {
    const apt = appointments.find(a => a.id === appointmentId);
    if (apt) {
      setActivePatientId(apt.patientId);
      setActiveTelehealthAptId(appointmentId);
    }
    setActiveTab('telehealth');
    showNotification('Connected to secure virtual rehabilitation room.');
  };

  const handleOpenBillingForApt = (apt: Appointment) => {
    setQuickClaimPatientId(apt.patientId);
    setIsQuickClaimOpen(true);
  };

  const handleOpenNewAppointment = (time?: string, provId?: string) => {
    setNewAptInitialTime(time || '10:00');
    setNewAptInitialProvId(provId);
    setIsNewAppointmentOpen(true);
  };

  const patientForSoap = patients.find(p => p.id === activeSoapModalPatientId);
  const providerForSoap = MOCK_PROVIDERS.find(p => p.id === patientForSoap?.primaryProviderId) || MOCK_PROVIDERS[0];
  const existingSoap = soapNotes.find(n => n.appointmentId === activeSoapModalAptId);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        onNewAppointmentClick={() => handleOpenNewAppointment()}
        onResetData={handleResetData}
        selectedProviderId={selectedProviderFilter}
        onProviderChange={setSelectedProviderFilter}
        providers={MOCK_PROVIDERS}
      />

      {/* Temporary Toast Alert */}
      {notification && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Main Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Module 1: Scheduling & Bay Management */}
        {activeTab === 'schedule' && (
          <ScheduleModule
            appointments={appointments}
            patients={patients}
            providers={MOCK_PROVIDERS}
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
            onUpdateStatus={handleUpdateAppointmentStatus}
            onNewAppointmentClick={handleOpenNewAppointment}
            onOpenSoapNote={handleOpenSoapNote}
            onStartTelehealth={handleStartTelehealth}
            onOpenBillingForApt={handleOpenBillingForApt}
            selectedProviderFilter={selectedProviderFilter}
            onProviderFilterChange={setSelectedProviderFilter}
          />
        )}

        {/* Module 2: Billing & Revenue Cycle */}
        {activeTab === 'billing' && (
          <BillingModule
            claims={claims}
            patients={patients}
            providers={MOCK_PROVIDERS}
            onSaveClaim={handleSaveClaim}
            onUpdateClaimStatus={handleUpdateClaimStatus}
            onRecordCopayPayment={handleRecordCopay}
          />
        )}

        {/* Module 3: Outcomes & Functional Measures */}
        {activeTab === 'outcomes' && (
          <OutcomesModule
            outcomes={outcomes}
            patients={patients}
            providers={MOCK_PROVIDERS}
            onSaveOutcome={handleSaveOutcome}
            selectedPatientId={activePatientId}
            onSelectPatientId={setActivePatientId}
          />
        )}

        {/* Module 4: Telehealth Virtual Rehab */}
        {activeTab === 'telehealth' && (
          <TelehealthModule
            patients={patients}
            providers={MOCK_PROVIDERS}
            appointments={appointments}
            activeAppointmentId={activeTelehealthAptId}
            onSaveSessionNotes={(patId, notes) => {
              showNotification('Virtual rehab notes recorded to patient chart.');
            }}
            onCompleteSession={(aptId) => {
              handleUpdateAppointmentStatus(aptId, 'completed');
            }}
          />
        )}

        {/* Module 5: Patient EHR & SOAP Notes */}
        {activeTab === 'patients' && (
          <PatientChartModule
            patients={patients}
            providers={MOCK_PROVIDERS}
            soapNotes={soapNotes}
            onSaveSoapNote={handleSaveSoapNote}
            selectedPatientId={activePatientId}
            onSelectPatient={setActivePatientId}
            onOpenNewClaimForPatient={(patId) => {
              setQuickClaimPatientId(patId);
              setIsQuickClaimOpen(true);
            }}
            onOpenOutcomeForPatient={(patId) => {
              setActivePatientId(patId);
              setActiveTab('outcomes');
            }}
          />
        )}
      </main>

      {/* Global New Appointment Modal */}
      {isNewAppointmentOpen && (
        <NewAppointmentModal
          isOpen={isNewAppointmentOpen}
          onClose={() => setIsNewAppointmentOpen(false)}
          onSave={handleSaveAppointment}
          patients={patients}
          providers={MOCK_PROVIDERS}
          initialDate={selectedDate}
          initialTime={newAptInitialTime}
          initialProviderId={newAptInitialProvId}
        />
      )}

      {/* Global SOAP Note Modal */}
      {activeSoapModalPatientId && (
        <SoapNoteModal
          isOpen={!!activeSoapModalPatientId}
          onClose={() => {
            setActiveSoapModalPatientId(null);
            setActiveSoapModalAptId(undefined);
          }}
          onSave={handleSaveSoapNote}
          patient={patientForSoap}
          provider={providerForSoap}
          appointmentId={activeSoapModalAptId}
          existingNote={existingSoap}
        />
      )}

      {/* Global Quick Claim Modal */}
      {isQuickClaimOpen && (
        <NewClaimModal
          isOpen={isQuickClaimOpen}
          onClose={() => setIsQuickClaimOpen(false)}
          onSave={handleSaveClaim}
          patients={patients}
          providers={MOCK_PROVIDERS}
          initialPatientId={quickClaimPatientId}
          initialDate={selectedDate}
        />
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
          <div>
            <span className="font-semibold text-slate-700">{CLINIC_INFO.name}</span> · {CLINIC_INFO.phone} · NPI: {CLINIC_INFO.npi}
          </div>
          <div className="font-mono text-[11px]">
            HIPAA Compliant EHR Architecture · ICD-10-CM · CPT / CMS-1500 Ready
          </div>
        </div>
      </footer>
    </div>
  );
}
